# Installation Guidelines
(Download a DOCX version of the Installation Guidelines for the web [here](Installation Guidelines_Installation Guide - OpenXmlViewer Xtensions.docx))
(Download a DOCX version of the Installation Guidelines for the commandline [here](Installation Guidelines_Installation Guide - OpenXmlViewer Xtensions Cmd.docx))

This section contains installation information for the various platforms supported by the OpenXMLViewer project. 
The installers are platform specific and follow the naming convention as below:
_<plugin name> _ <os> _ <browser>.<type>_


Eg. The Windows installer is called OpenXMLViewer _ win _ firefox.xpi. 
For Linux, the same is called OpenXMLViewer_ linux _ firefox.xpi

The installers are packaged in a zip/tar file containing the above installers and supporting files/documentation.

# Commandline utility installation

The installation files are named as below 

Eg. The Windows installer is called OpenXMLViewer _ win _ cmd.xpi. 
For Linux, the same is called OpenXMLViewer_ linux _ cmd.xpi.

The installers are packaged in a zip file containing the above installers and supporting files/documentation.  The commandline interface is called OpenXMLViewer.exe on windows and OpenXMLViewer on linux.

**MS Windows XP, Vista, 2003, 2008 Server**

Extract the files from the zip to the required folder. 

**Linux**

Root access/install permissions is required in order to install the files. Write access to /usr/local/lib and /usr/local/bin is required for the installation to be successful.
Download the tar archive and extract it to a local directory.

> tar –xvf OpenXMLViewer _ linux _ cmd.tar
> cd OpenXMLViewer _ linux _ cmd
> ./install.sh

This will install the files to /usr/local/lib and /usr/local/bin folders


# Browser plug-in installation

## MS Windows XP, Vista, 2003, 2008 Server

The OpenXML Viewer Firefox plug-in for MS Windows can be downloaded [here](http://www.codeplex.com/OpenXMLViewer/Release/ProjectReleases.aspx?ReleaseId=19713)

* Extract the zip file to your local folder. 
* The zip file contains the Readme.txt, the License.txt file and the Firefox extension installer OpenXMLViewer _ win _ firefox.xpi.
* Open the .xpi file using firefox. The codesigned plugin information is displayed on the screen, signed against MindTree Limited.
![](Installation Guidelines_Install.jpg)
* Click on the Install Now button. 

![](Installation Guidelines_InstallComplete.jpg)
* Once the plugin is installed, firefox prompts for a restart. Restart firefox as prompted.
* Once firefox is restarted, navigate to Tools>Add ons. In the extensions tab, OpenXMLViewer should be visible.

## Linux

**Prerequisites**
Root access/install permissions is required in order to install the files. Write access to /usr/local/lib and /usr/lib/mozilla is required for the installation to be successful.

* [Download](http://www.codeplex.com/OpenXMLViewer/Release/ProjectReleases.aspx?ReleaseId=19713) the tar archive and extract it to a local directory. 
 > tar –xvf OpenXMLViewer _ linux _ firefox.tar
 > cd OpenXMLViewer _ linux _ firefox

**Step 1**
* Open a Super User shell (su)
* Execute install.sh script. This will install the plug-in files and create the necessary symbolic links in /usr/local/lib folder.

**Step 2**
* Open the OpenXMLViewer _ linux _ firefox.xpi with Firefox after logging in as the user. This will in-stall the plugin for Firefox for the particular user. This is similar to the Windows installation (see above)
* Restart Firefox. The plugin should be present in Tools>Add-ons>Plugins.

For installing the OpenXMLViewer plug-in for other users, log in as the required user. Open the OpenXMLViewer _ linux _ firefox.xpi using Firefox. The plug-in will be installed for the user.

## Uninstalling the plugin
* To uninstall the plug-in from Firefox, 
* Open Firefox
* Navigate to Tools>Addons>Extensions
* Click on the Uninstall button corresponding to the plug-in “OpenXMLViewer”.
* Restart firefox
