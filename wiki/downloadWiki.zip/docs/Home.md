[Demo](http://www.youtube.com/watch?v=NKSF6w0EK0s) [Discussions](http://openxmlviewer.codeplex.com/Thread/List.aspx) [Issues](http://openxmlviewer.codeplex.com/WorkItem/List.aspx)
# Overview

 The Office Open XML format specification has been approved as a free and open [Ecma International standard](http://www.ecma-international.org/publications/standards/Ecma-376.htm). A newer improved version is approved as an  [ISO/IEC standard](http://www.iso.org/iso/iso_catalogue/catalogue_tc/catalogue_tc_browse.htm?commid=45374). 

The OpenXML Document Viewer project is an outcome of the feedback from participants of a series of [Document Interoperability Initiative workshops](http://www.documentinteropinitiative.org/recentevents.aspx). The main goal of the OpenXML Document Viewer project is to create software tools, plus guidance, showing how documents created using Open XML Format can be translated to HTML. As a result,  Independent Software Vendors (ISVs), Solutions Integrators & Mobile Solution providers can use these tools to enable their customers view Open XML documents on heterogeneous platforms and browser applications. The OpenXML Viewer is available under the open source Microsoft Public License (MS-PL), which allows anyone to use the tools, submit bugs and feedback, or contribute to the project. We have chosen to use an Open Source development model that allows developers from all around the world to participate and contribute to the project. 

For a video demo of the latest release, please see the post titled [OpenXML Document Viewer v1 released: viewing .DOCX](http://blogs.msdn.com/interoperability/archive/2009/05/17/openxml-document-viewer-v1-released-viewing-docx-files-as-html.aspx) on the Microsoft Interoperability Team Blog. 

We encourage you to view video demonstrations of the [translation engine](http://www.youtube.com/watch?v=el-3TKVgX-0) and the [FireFox browser plug-ins](http://www.youtube.com/watch?v=NKSF6w0EK0s) on YouTube.

# Roadmap

#### [Milestone1: November 2008 Community Technology Preview](http://www.codeplex.com/OpenXMLViewer/Release/ProjectReleases.aspx?ReleaseId=19713)
For the first milestone, the focus of the project will be on building the core architectural components for the OpenXML to HTML translator that can be leveraged to build the plug-ins for various platforms to enable cross-platform support.

The following features are planned for the first milestone: 

* Core transformation framework
* Browser plug-ins for Firefox 3.0.x on Windows and Linux
* Word Document features including translation of 
	* font types
	* images 
	* text styles 
	* diagrams 
	* tables
	* hyperlinks
* Test Results 

The public release of OpenXMLViewer is available in the [Releases section](http://www.codeplex.com/OpenXMLViewer/Release/ProjectReleases.aspx).

#### [OpenXMLViewer v1.0 Release](http://openxmlviewer.codeplex.com/Release/ProjectReleases.aspx?ReleaseId=25391)
We are happy to announce the release of OpenXMLViewer v1.0. The following is a list of features that are released.

* Support for Document Themes
* Server side support showcase scenario website
* Support for more drawing shapes including Parallelogram, Trapezium, Diamond, Block arrows, lines, 5-pointed Star, Hexagon and triangles (right angled and isosceles)
* Plugins for Opera 9.x on Windows and Linux
* Plugins/Browser Helper Objects (BHO) for IE 7 and IE 8b
* Performance tuning for server-side scenario
* Support for Math ML equations


Thank you for your valuable feedback for the previous milestone release. Looking forward to more participation in [Discussions](http://www.codeplex.com/OpenXMLViewer/Thread/List.aspx)  for the v1.0 release. 

# Contributors

* **[MindTree Limited](http://www.mindtree.com)** (Analysis and Development)
MindTree is a global IT and R&D Services Company co-headquartered in the U.S. and India. With a passion for customer satisfaction, MindTree partners with its clients to create a transparent, value-based relationship. MindTree provides a range of IT and R&D services to companies across a variety of industry segments.

* **[Microsoft Corporation](http://www.microsoft.com/interop)** (Architectural Guidance, Technical Support, and Project Management)

# Licensing Model
The OpenXMLViewer is available under the open source Microsoft Public License (MS-PL), which allows anyone to use the tools, submit bugs and feedback, or contribute to the project. We have chosen to use an Open Source development model that allows developers from all around the world to participate and contribute to the project