# Functional Overview of OpenXML Viewer
(Download a DOCX version of the Functional Overview [here](Functional Overview_Functional Overview - OpenXmlViewer Xtensions.docx))
## Executive Summary
The Office OpenXML file format is an approved free and open ISO/IEC standard. The format is based on the Open Packaging Convention (OPC) and is XML based. 

As it is an open standard and XML based, the OpenXmlViewer Xtensions project provides a guided implementation for visualizing OpenXML based Word 2007 (docx) documents in xHTML, which is open and free in the spirit of Open Source.

This document provides a functional overview of the OpenXML Viewer project.

## Basic Use Cases

The OpenXML Viewer Xtensions project aims at ease of use and browser integrated viewing of Word 2007 documents. 
The basic use case consists of users who do not have a means to view OpenXML based .docx docu-ments. With the OpenXML Viewer browser extension, the user can convert the word docx document into html and view the contents of the document in a browser.
![](Functional Overview_Usecase1.JPG)

## Use case: Open DocX File
**Preconditions**
OpenXML Viewer plugin is installed.

**Basic Flow**
* 1. User opens document (attachment or fileshare) using the browser
* 2. Browser detects the document MIME type and extension 
* 3. Browser calls the plugin
* 4. Plugin initializes and received the document file from the browser
* 5. Plugin opens the document as per Open Packaging Convention and reads the xml files.

**Alternate flow**
* 1. User opens document from the file system.
* 2. User chooses to open the document file using the OpenXMLViewer.exe commandline application
* 3. OpenXMLViewer.exe reads the file as per Open Packaging Convention and reads the xml files

**Additional Information**
Refer to [Open Packaging Specifications](http://www.microsoft.com/whdc/xps/downloads.mspx) for information regarding the OpenOffice Document packaging

## Use case: Convert Docx to xHTML
**Preconditions**
The Docx file is successfully read (refer use case Open Docx)

**Basic Flow**
* 1. Plug-in processes various xmls for word features including relationship resolution within the document (links, styles, images etc)
* 2. Plug-in transforms the xml into xhtml
* 3. Plug-in displays the converted xHTML to the user.

**Future expectations**
The OpenXML transformation engine can be made available across various OSes and platforms like in-ternet tablets, mobile media devices, server based conversion tasks for providing a web preview to Docx documents etc

## Usage guide
**Browser plug-in**

The browser plug-in, once installed will intercept Word 2007 documents and convert them to html. The basic usage involves clicking on a hyperlink or opening an FTP containing Word 2007 (.docx) files.

The browser plug-in will translate the docx stream into xHTML and render it in the same page.

![](Functional Overview_Usage1.JPG)

Consider the case of opening a webpage that contains the Word 2007 document in a hyperlink. Click on hyperlink to open the document.

![](Functional Overview_Usage2.JPG)
Firefox translates the content document into xhtml and displays it in the browser.

**Command-line interface**

The document translation can also be triggered from the command-line in the shell. Run the following command from the command prompt to convert the docx file to xHtml.

_Note:_
The command-line utility is available in the extracted folder on windows. On linux, the commandline utility is copied to /usr/local/bin.

To process the docx, execute the command as follows.

OpenXMLViewer <source file> <destination path>

Eg. 
OpenXMLViewer D:\Input.docx D:\ouput
OpenXMLViewer ~/Input.docx ~/ouput

The input and destination paths should be absolute paths and not relative paths.

The above commands will convert the document and place the output xhtml file and supporting files to the destination path (D:\output\) or ~/output).

Once the conversion is complete, the application will launch the file with the associated application (use Open With.. to associate the file type .xhtml with Firefox)
