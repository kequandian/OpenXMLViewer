## Documentation
The following documentation is available for the OpenXML Viewer plug-in and command line interface. 

* [Installation Guidelines for Linux and Windows](http://www.codeplex.com/OpenXMLViewer/Wiki/View.aspx?title=Installation%20Guidelines) - This page contains the installation steps and details required to install the Firefox browser plugin add-on for Windows and Linux.
* [Functional overview of the OpenXMLViewer plugin](http://www.codeplex.com/OpenXMLViewer/Wiki/View.aspx?title=Functional%20Overview) - This page provides an overview of the basic use cases along with a screen action guide for using the browser plug-in.
* [Technical and architectural overview](http://www.codeplex.com/OpenXMLViewer/Wiki/View.aspx?title=Technical%20Overview&referringTitle=Documentation) - The technical and architectural overview of the browser plug-in is present here. The architecture considers the usage of the core transformation from docx to html in non-browser and cross browser environments.
## Testing 
Testing was conducted on the application at different levels.

**Functional Testing**
At the functional level, the basic functionality was tested for correct reproduction of docx elements in HTML. Deviations and not supported features were identified and documented. The following documents were used to test the base functionality.
[Functional Test Documents](Documentation_Functional.zip)

**Test coverage**
Besides the functional tests, the following documents were used as test coverage documents. They include real world documents to reproduce the end-user scenarios.
[Test Coverage 1](Documentation_Test_Coverage1.zip)
[Test Coverage 2](Documentation_Test_Coverage2.zip)
[Test Coverage 3](Documentation_Test_Coverage3.zip)
[Test Coverage 4](Documentation_Test_Coverage4.zip)
[Test Coverage 5](Documentation_Test_Coverage5.zip)


The Test Defect metrics based on the above tests can be viewed [here](Documentation_Test Metrics.xls)

**Regression tests**
Regression tests after builds were done using the [Regression Test Documents](Documentation_Regression.zip)

## November CTP Release Features
The following list of features which are included in the release November 2008 CTP release
* Core transformation framework 
* Browser plug-ins for Firefox 3.0.x on Windows XP, Vista, 2003, 2008 and Linux (OpenSUSE 11.0)
* Command-line interface for converting Word 2007 documents to xHTML for Windows and Linux
* Word Document features including translation of 
* Font types 
* Images 
* Text styles 
* Tables 
* Hyperlinks 
* Background color
* VML to SVG Conversion (Diagram)
	* Rectangle
	* Oval 
	* Rounded Rectangle
	* Fill colors
	* Stroke

## FAQ (Frequently Asked Questions)

**Q. Where can I find the installation files?**
_A._ Head over to the Releases section and select the latest release. The Windows installer is called _OpenXMLViewer_win_firefox.xpi_. The linux installer is called _OpenXMLViewer_linux_firefox.tar_.

**Q. I found some undocumented issues. What do I do about this?**
_A._ You can log issues, suggestions, feedback in the [Issue Tracker](http://www.codeplex.com/OpenXMLViewer/WorkItem/List.aspx). We'd love to hear from you. So do provide your feedback. We look forward to this.

**Q. I have installed the plug-in on Linux. The plug-in still does not show up in Firefox. What should I do?**
_A._  The following steps may be required to get the plug-in to come up on Linux. 
  1. Ensure that the user has read permissions to /usr/lib/mozilla/plugins directory
  2. run the following script as the logged in user after shutting down firefox:
  > ln -s /usr/lib/mozilla/plugins/NPDOCX.so  ~/.mozilla/plugins/NPDOCX.so

  If the plugins folder does not exist in the ~/.mozilla folder, create the plugins folder and retry the above link.

  3. Ensure that /usr/local/lib entry exists in /etc/ld.so.conf
  4. Restart the OS and try again.

  If the above steps donot work, please log an entry in the [Issue Tracker](http://www.codeplex.com/OpenXMLViewer/WorkItem/List.aspx) with the details of Firefox version info and OS version info.

**Q. Is there a linux uninstallation/cleanup script?**
_A._ Run [this script file](Documentation_Cleanup.sh) from the commandline to cleanup the installation of the plugin/commandline application.