# Technical and architectural overview
(You can download a DOCX version of the Technical overview [here](Technical Overview_Architecture - OpenXmlViewer Xtensions.docx)

## Summary
The Microsoft OpenXmlViewer Xtensions project consists of the development of a browser plugin that is cross browser and cross platform, which will render OpenXML Word documents (docx) in html. 

This is the technical basis for pilot phase of the OpenXml Viewer Xtensions project. This document covers the following topics:
* Architectural Considerations 
* Logical Architecture.

## Architectural Considerations
**Technology Considerations**
The Microsoft OpenXml Viewer is a cross browser cross OS plugin. The core of the application has to be OS independent. Therefore, the application is developed using C++.

**Future possibilities**
The generated html from the docx file can be rendered using silverlight and similar rich platforms. The same can be used in a server scenario to render docx files as html.

## Tool Considerations
The list of language and tools used is given below:

|| # || Tool/Technology || Usage ||
| 1 | C++ | Core technology platform|
| 2 | Xalan (c++) | XSLT Processing|
| 3 | Xerces (c++) | XML Processing|
| 4 | zlib| Docx (zip) file decompressing|
| 5 | Firefox | Plugin extensions|

## Logical Architecture
![](Technical Overview_logical arch.JPG)

### Application Interface
This layer provides the user interface for the application. 
* Browser plugin interface - The browser plug-in interface (specific interfaces for different brows-ers) will allow the document transformation framework to be leveraged across different browsers. 
* OS/File system interface – This interface will be a command-line based interface for opening docx files from the file system. Docx files will be registered against this interface. The application will render the docx files in html.

### Transformation Service
The Transformation Service is the core of the application. Along with the XSLT transform, this service will convert the input docx file(s) into html. 

The bulk of the conversion of XML to HTML will be done using XSLT (Extensible Stylesheet Language Transformations)

### Framework Helpers
The Framework Helpers are 3rd party components that provide the following functionality.
* Xalan – This framework provides XSLT transformation capabilities to the Transformation Service
* Xerces – This framework provides XML support for working with the docx files and other xml files.
* zlib – Docx is a zip compressed file as specified by Open Packaging Conventions (OPC). Zlib li-brary will be made use of to uncompress the zip package.

### Utilities
The utilities provide supporting functionality such as:
* File system access
* Logging
* Conversion of VML to SVG
* XML Helper methods