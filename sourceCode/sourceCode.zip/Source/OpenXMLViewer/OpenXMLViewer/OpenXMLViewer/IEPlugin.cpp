// IEPlugin.cpp : Implementation of CIEPlugin

#include "stdafx.h"
#include "IEPlugin.h"
#include <ExDispID.h>
#include <DocumentTransform.h>
// CIEPlugin

STDMETHODIMP CIEPlugin::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = {	&IID_IIEPlugin	};

	for (int i=0; i < sizeof(arr)/sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CIEPlugin::SetSite(IUnknown *pUnkSite)
{
	CComQIPtr<IWebBrowser2, &IID_IWebBrowser2> WB2Ptr;

	WB2Ptr = pUnkSite; 

	if (WB2Ptr == NULL)
	{
		return E_INVALIDARG;
	}

//store the IConnectionPointerContainer pointer
	m_ConnPtrContPtr = WB2Ptr;

	if (m_ConnPtrContPtr == NULL)
	{
		return E_POINTER;
	}
	
	return IEAdvise();
}


STDMETHODIMP CIEPlugin::IEAdvise(void)
{
	HRESULT hr;
	CComPtr<IConnectionPoint> spCPtr;

	// Receives the connection point for WebBrowser events
    hr = m_ConnPtrContPtr->FindConnectionPoint(DIID_DWebBrowserEvents2, &spCPtr);
    
	if (FAILED(hr))
	{
		return hr;
	}

    // Subscribe the event handlers to the container
	hr = spCPtr->Advise(reinterpret_cast<IDispatch*>(this), &m_dwCookie);

    return hr; 
}

STDMETHODIMP CIEPlugin::IEUnAdvise(void)
{
	HRESULT hr;
	CComPtr<IConnectionPoint> spCPtr;

	// Receives the connection point for WebBrowser events
    hr = m_ConnPtrContPtr->FindConnectionPoint(DIID_DWebBrowserEvents2, &spCPtr);

    if (FAILED(hr))
	{
		return hr;
	}

    // Unsubscribe the event handlers to the container
	hr = spCPtr->Unadvise(m_dwCookie);
    return hr;
}

STDMETHODIMP CIEPlugin::IEQuit(void)
{
	return  IEUnAdvise();
}


STDMETHODIMP CIEPlugin::Invoke(DISPID dispidMember, REFIID riid,
                                LCID lcid, WORD wFlags,
                                DISPPARAMS* pDispParams,
                                VARIANT* pvarResult,
                                EXCEPINFO*  pExcepInfo, UINT* puArgErr)
{

    if (!pDispParams)
	{
        return E_INVALIDARG;
	}
 
    switch(dispidMember)
	{
	    case DISPID_BEFORENAVIGATE2:
	         IEOnBeforeNavigate2(pDispParams);
			 break;

		case DISPID_FILEDOWNLOAD:
			break;
	}
    return S_OK;
}

void CIEPlugin::IEOnBeforeNavigate2(DISPPARAMS* pDispPrms)
{	
	char tempFileName[1029], tempFolderPath[1029];
	
	CComQIPtr<IWebBrowser2, &IID_IWebBrowser2> WB2Ptr;
	CAtlString url;
	VARIANT_BOOL*                              ptrBoolCancel;
	VARTYPE                                    vt;
    
	// Check the type of IWebBrowser2
	vt = pDispPrms->rgvarg[6].vt; 
	if(vt==0x0009)
    {
	    WB2Ptr = pDispPrms->rgvarg[6].pdispVal;
	}
	else 
	{
		// Wrong type, return.
		return;
	}

	// Check the first parameter type is VT_BYREF|VT_BOOL or not
	vt = pDispPrms->rgvarg[0].vt; 
	if(vt == 0x400B)
	{
	    ptrBoolCancel = pDispPrms->rgvarg[0].pboolVal;
	}
	else
	{
		// Wrong type, return.
		return;
	}

	// Check the URL parameter type 
	vt = pDispPrms->rgvarg[5].vt; 
	if(vt == 0x400C)
	{
	    USES_CONVERSION;
        url = OLE2T(pDispPrms->rgvarg[5].pvarVal->bstrVal);
	}
	else
	{
		// Wrong type, return.
		return;
	}	

	// *********************************************************

	int loc = url.ReverseFind('.');
	url = url.MakeLower();
	int docx_found = url.Find(_T("docx"), loc);
	int http_find = url.Left(4).Find(_T("http"),0);
	int ftp_find = url.Left(3).Find(_T("ftp"),0);

	if (docx_found != -1 && http_find== -1
		&& ftp_find == -1)
	{
		
		DocumentTransform::initialize();
		{
			DocumentTransform DocTrans;

			DocTrans.createTempFolder(tempFolderPath);
			sprintf(tempFileName, "%s\\input.docx", tempFolderPath);
			CString cstr_tempFileName(tempFileName);
			CopyFile(url, cstr_tempFileName, false);
			DocTrans.browserType = IE;
			WB2Ptr->put_StatusText(_T("The OpenOffice document file is getting processed."));
			int result = DocTrans.convertDocumentToHTML();
			
			cstr_tempFileName.Empty();

			CString cstr_tempFolderPath(tempFolderPath);
			cstr_tempFileName.Format(_T("file://%s/output.html"), cstr_tempFolderPath);


			CComVariant vURL = cstr_tempFileName;
			CComVariant vNull;
			VARIANT frame;
			vNull.vt = VT_NULL;
			VARIANT *TargetFrameName = pDispPrms->rgvarg[3].pvarVal;
//			TargetFrameName->bstrVal = SysAllocString(L"_self");
			*ptrBoolCancel = TRUE;
			WB2Ptr->Navigate2(&vURL,&vNull,TargetFrameName,&vNull,&vNull);
		}

		DocumentTransform::release();
	}
	
}


void CIEPlugin::IDOnFileDownload(DISPPARAMS* pDispParams)
{	
	
}

