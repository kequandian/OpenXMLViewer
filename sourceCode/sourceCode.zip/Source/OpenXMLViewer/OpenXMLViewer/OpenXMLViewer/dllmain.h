// dllmain.h : Declaration of module class.

class COpenXMLViewerModule : public CAtlDllModuleT< COpenXMLViewerModule >
{
public :
	DECLARE_LIBID(LIBID_OpenXMLViewerLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_OPENXMLVIEWER, "{5DDD660E-DB36-47DB-9FAD-68F460B425CE}")
};

extern class COpenXMLViewerModule _AtlModule;
