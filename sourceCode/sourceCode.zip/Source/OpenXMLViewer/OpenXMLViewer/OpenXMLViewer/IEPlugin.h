// IEPlugin.h : Declaration of the CIEPlugin

#pragma once
#include "resource.h"       // main symbols
#include "ExDisp.h"
#include "OpenXMLViewer_i.h"
#include "_IIEPluginEvents_CP.h"


#if defined(_WIN32_WCE) && !defined(_CE_DCOM) && !defined(_CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA)
#error "Single-threaded COM objects are not properly supported on Windows CE platform, such as the Windows Mobile platforms that do not include full DCOM support. Define _CE_ALLOW_SINGLE_THREADED_OBJECTS_IN_MTA to force ATL to support creating single-thread COM object's and allow use of it's single-threaded COM object implementations. The threading model in your rgs file was set to 'Free' as that is the only threading model supported in non DCOM Windows CE platforms."
#endif



// CIEPlugin

class ATL_NO_VTABLE CIEPlugin :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CIEPlugin, &CLSID_IEPlugin>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CIEPlugin>,
	public CProxy_IIEPluginEvents<CIEPlugin>,
	public IObjectWithSiteImpl<CIEPlugin>,
	public IDispatchImpl<IIEPlugin, &IID_IIEPlugin, &LIBID_OpenXMLViewerLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CIEPlugin()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_IEPLUGIN)


BEGIN_COM_MAP(CIEPlugin)
	COM_INTERFACE_ENTRY(IIEPlugin)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(IObjectWithSite)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CIEPlugin)
	CONNECTION_POINT_ENTRY(__uuidof(_IIEPluginEvents))
END_CONNECTION_POINT_MAP()
// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

	// IDispatch Methods
	//
	STDMETHOD(Invoke)(DISPID dispidMember,REFIID riid, LCID lcid,
		WORD wFlags, DISPPARAMS* pdispparams,
		VARIANT* pvarResult, EXCEPINFO* pexcepinfo,
		UINT* puArgErr);

	//
	// IOleObjectWithSite Methods
	//
	STDMETHOD(SetSite)(IUnknown *pUnkSite);

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}

public:
	
private:
	CComQIPtr<IConnectionPointContainer, &IID_IConnectionPointContainer> m_ConnPtrContPtr;
	DWORD m_dwCookie;   // Connection Token - used for
                       // Advise and Unadvise

    
	enum ConnectType { Advise, Unadvise };   // What to do when managing 
                                            // the connection

	STDMETHOD(IEAdvise)(void);
	STDMETHOD(IEUnAdvise)(void);
	STDMETHOD(IEQuit)(void);

	void IEOnBeforeNavigate2(DISPPARAMS* pDispParams);
	void IDOnFileDownload(DISPPARAMS* pDispParams);
};

OBJECT_ENTRY_AUTO(__uuidof(IEPlugin), CIEPlugin)
