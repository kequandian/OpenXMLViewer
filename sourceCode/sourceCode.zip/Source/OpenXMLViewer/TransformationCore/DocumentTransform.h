/**
  @file /DocumentTransform.h

  @brief OpenXML to HTML Conversion Procedures
*/

//Include Files
#include <xercesc/dom/DOM.hpp>
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/util/XMLException.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/dom/DOMException.hpp>
#include <xercesc/util/OutOfMemoryException.hpp>
#include <xercesc/dom/DOMErrorHandler.hpp>
#include <xercesc/framework/LocalFileFormatTarget.hpp>
#include <xercesc/framework/StdOutFormatTarget.hpp>

#include <xalanc/XercesParserLiaison/XercesParserLiaison.hpp>
#include <xalanc/XercesParserLiaison/XercesDOMSupport.hpp>
#include <xalanc/Include/PlatformDefinitions.hpp>
#include <xalanc/XalanTransformer/XalanTransformer.hpp>
#include <xalanc/XalanTransformer/XercesDOMWrapperParsedSource.hpp>
#include <xalanc/XalanTransformer/XalanSourceTreeWrapperParsedSource.hpp>
#include <xalanc/XalanDOM/XalanDOMString.hpp>
#include <xalanc/XSLT/XSLTResultTarget.hpp>
#include <ReadUnicodeMemBlock.h>
#include <map>
#define _BIND_TO_CURRENT_VCLIBS_VERSION 1

XERCES_CPP_NAMESPACE_USE
XALAN_USING_XERCES(XMLPlatformUtils)
XALAN_USING_XALAN(XalanTransformer)
//XALAN_USING_XERCES(DOMDocument)
using namespace std;
XALAN_USING_XALAN(XercesDOMSupport)
XALAN_USING_XALAN(XercesParserLiaison)
XALAN_USING_XALAN(XercesDOMSupport)
XALAN_USING_XALAN(XercesDOMWrapperParsedSource)

enum browser_type
{
	FIREFOX = 1, OPERA = 2, IE = 3
};

class DocumentTransform
{

public:
	DocumentTransform();
	~DocumentTransform();

	static void initialize()
	{
		try 
		{
			XMLPlatformUtils::Initialize();
			XalanTransformer::initialize();
		}
		catch (const XMLException& toCatch)
		{
			char *pMessage = XMLString::transcode(toCatch.getMessage());
			fprintf(stderr, "Error during initialization! \n  %s \n", pMessage);
			XMLString::release(&pMessage);
			XMLPlatformUtils::Terminate();
		}
		catch(...)
		{
			fprintf(stderr, "Error during initialization! \n  %s \n");
			XMLPlatformUtils::Terminate();		
		}
	}

	static void release()
	{
		XalanTransformer::terminate();
		XMLPlatformUtils::Terminate();
	}
	
	browser_type browserType;
	int createTempFolder(char *path);
	int removeTempFolder();
	int parseDocuments(char *);
	int mergePackageDocuments();
	int parseWithContext();
	int applyXSLTransform(char *);
	int applyXSLTransform();
	int preProcessParsedFile();
	int convertDocumentToHTML(char *xslt_path);
	int convertDocumentToHTML();
	int convertVML2SVG(map<const XMLCh*, const XMLCh*> *imgmap);
	string sourceFileName;

private:
	XercesDOMParser* parserA;
	XercesDOMParser* parserB;
	XercesDOMParser* parserWithContext;
	XERCES_CPP_NAMESPACE::DOMDocument *DOMTree;
	XalanTransformer theXalanTransformer;
	bool DOCParse;
};