#ifndef _UNZIPDOCX_H
#define _UNZIPDOCX_H

#ifndef _MINIUNZ_H
#include "miniunz.h"
#endif

#define MAXFILENAME (256)

class UnzipDocx{
private :
	 const char *zipfilename; // Name of the zip file
	 const char *filename_to_extract; // Name of the single file to be extracted
	 const char *dirname; // Name of the directory in whichfiles should be exracted
	 const char *password;
	 unzFile uf;
	 char filename_try[MAXFILENAME+16];

	 int open_zipfile(); // To open zip file

	 void close_zipfile(); // To close zip file

	 //char *getDirectoryName(const char * zipfile);

public :
	UnzipDocx();	

	UnzipDocx(char *zipfile);

	UnzipDocx(char *zipfile,char *dir);

	UnzipDocx(char *zipfile,char *dir,char *file_to_extract);

	void get_file_list(); // To get the list of files present in the zip file

	bool extract_all_files(); // To extract all files from the zip file

	void extract_single_file(); // To extract a single file from the zip file
};
#endif
