#ifndef _MINIUNZ_H
#define _MINIUNZ_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef _unz_H
#include "unzip.h"
#endif



extern int ZEXPORT do_list OF((unzFile uf));

extern int ZEXPORT do_extract OF((unzFile uf,int opt_extract_without_path,int opt_overwrite,const char* password));
    
extern int ZEXPORT do_extract_onefile OF((unzFile uf,const char* filename,int opt_extract_without_path,int opt_overwrite,const char* password));
    
#ifdef __cplusplus
}
#endif
#endif
