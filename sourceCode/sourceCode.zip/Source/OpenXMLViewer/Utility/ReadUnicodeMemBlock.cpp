//class ReadUnicodeMemBlock defination

#include"ReadUnicodeMemBlock.h"



//Default constructor 
FileSystemUtil::FileSystemUtil()
{

}//end of constructor


//Create a directory by taking path of the directory as an argument
//Returns 0 for success and -1 for failure
int FileSystemUtil::create_directory(string path)
{
	//For Widows operating system  
	#ifdef _WIN32
    {
	    //cout<<"WINDOWS operating system"<<endl;
		if( mkdir(path.c_str())==0 )
		{
			//cout<<"Directory created successfully"<<endl;
			return SUCCESS;
		}
		else
		{
			//cout<<"Unable to create a directory"<<endl;
			return FAILURE;
		}
	}    
    #endif

	//For Linux operating system
    #ifdef __linux
    {
		//cout<<"LINUX Operating system"<<endl;
		if( mkdir(path.c_str(), 0777)==0 )
		{
			//cout<<"Directory created successfully"<<endl;
			return SUCCESS;
		}
		else
		{
			//cout<<"Unable to create a directory"<<endl;
			return FAILURE;
		}
	}
    #endif

}//end of create_directory(string path)


//Delete the directory along with the subdirectory and files under that directory .
//Takes path of the directory as an argument
//Returns 0 for success and -1 for failure
int FileSystemUtil::delete_directory(string str)
{
	    //For Windows operating system
        #ifdef _WIN32
		{
			LPCTSTR lpszDir=LPCTSTR(str.c_str());
	        noRecycleBin = true;
	        len = _tcslen(lpszDir);

	        pszFrom = new TCHAR[len+2];

	        _tcscpy(pszFrom, lpszDir);
	        pszFrom[len] = 0;
	        pszFrom[len+1] = 0;
  
            //no status display
	        fileop.hwnd   = NULL; 

			//delete operation
	        fileop.wFunc  = FO_DELETE;

			//source file name as double null terminated string
	        fileop.pFrom  = pszFrom; 

			//no destination needed
	        fileop.pTo    = NULL;   

			//do not prompt the user
	        fileop.fFlags = FOF_NOCONFIRMATION|FOF_SILENT;  
			  
	        if(!noRecycleBin)
		    fileop.fFlags |= FOF_ALLOWUNDO;

	        fileop.fAnyOperationsAborted = FALSE;
	        fileop.lpszProgressTitle     = NULL;
	        fileop.hNameMappings         = NULL;
	
	        ret = SHFileOperation(&fileop);
	        delete [] pszFrom;  
	        if(ret == 0)
			{
				return SUCCESS;

			}
			else
			{
				return FAILURE;
			}
        }
        #endif

	    //For Linux operating system
		//Using system command to delete the directory
	    #ifdef __linux
        {
			//cout<<"LINUX Operating system"<<endl;
			command = "rm -r ";
            command+=str;
            if(system(command.c_str())==0)
		    {
				//cout<<"Directory deleted successfully"<<endl;
		        return SUCCESS;
			}
		    else
	        {
				//cout<<"Unable to delete the directory"<<endl;
			    return FAILURE;
		    }

		}
		#endif
	
}//end of delete_directory(string path)


// Method read the file passed as an argument, allocate space 
//in the memory block and store the contents of that file into 
//the memory , returns 0 for success and -1 for failure
int FileSystemUtil::store_file_memory( string filepath )
{
	file_stream.open( filepath.c_str() , ios::in | ios::binary | ios::ate  );	
	if ( file_stream.is_open() ) 
    {
		//cout<<"File opened successfuly"<<endl;
		file_current_size = file_stream.tellg();
		file_content = new wchar_t[file_current_size];
		file_stream.seekg( 0, ios_base::beg );
		file_stream.read( file_content, (streamsize)file_current_size );
		//cout<<"The file is now closing"<<endl;
		file_stream.close();
		return SUCCESS;
	}
	else
	{
		//cout<<"Unable to open"<<endl;
		return FAILURE;
	}
}//end of store_file_memory()


//Get the address of the memory block
wchar_t *FileSystemUtil::getmemblockaddress()
{
	//cout<<"The address of the memoryblock is "<<&file_content<<endl;
	return file_content;
}//end of getmemblockaddress


//Store the contents of memory into another new file.
//Takes memory block address and file path as argument.
//Returns 0 for success and -1 for failure
int FileSystemUtil::store_memory_file(wchar_t *ptr_memblock, string filepath_new)
{
	//cout<<"Create another file to store the memory contents"<<endl;
	file_stream.open( filepath_new.c_str() , ios::out|ios::app );
	if(file_stream.is_open())
	{
		//cout<<"New file opened to store the memory contents"<<endl;
		//store the memory contents to the newfile
		file_stream << ptr_memblock;
		//cout<<"The new file is now closing"<<endl;
		file_stream.close();
		return SUCCESS;
	}
	else
	{
		//cout<<"Unable to open the new file"<<endl;
		return FAILURE;
	}

}//end of store_meory_file()


//Copy only for .docx file
//Read Write operation on .docx file,
//This function takes source path and destination path as two arguments,
//if copied successfully returns 0 otherwise -1 for failure
int FileSystemUtil::copy_file(string source, string destination)
{
	//Open the source file in read and binary mode
	fr = fopen( source.c_str(), "rb" ) ;
    
	//check for the existance of the source file
	if(fr==NULL)
	{
		cout<<"The specified file "<<source<<" does not exist, please enter the correct file path."<<endl;
        return FAILURE;
	}
	
    //Get the size of the source file and
	//based on this size allocate memory for 
	//desination file
	fseek(fr,0l,SEEK_END);
    sourcelength=ftell(fr);
	//cout<<"The size of the source file is "<<sourcelength<<endl;
	memblock=new char[sourcelength];
	//come back to the begging of the file
    rewind(fr);     


	//Open the destination file in write and binary mode
	//If destination file is  exist then overwrite the contents
	//with the contents of the source file .
	//If the destination file is not exist then create a new file 
	//with specified directory and copy the contents of the source 
	//file to teh new file.
	fw = fopen( destination.c_str() , "wb" ) ;
    
	
	//check for the existance of the desination file
	if(fw==NULL)
	{
		cout<<"The specified file "<<destination<<" does not exist, please enter the correct file path."<<endl;
		return FAILURE;

	}
	
	//Start copy from source file to destination file
	//cout<<"Start Coping"<<endl<<endl;
	
	fread(memblock,sizeof(char), 1, fr);
	while(!feof(fr))
	{
		fwrite(memblock, sizeof(char), 1, fw);
		fread(memblock, sizeof(char), 1, fr);		
	}
    
	fclose(fr);
	fclose(fw);

	return SUCCESS;

	
}//end of copy_file()



//Destructor
FileSystemUtil::~FileSystemUtil()
{
	//delete[] file_content;
}


