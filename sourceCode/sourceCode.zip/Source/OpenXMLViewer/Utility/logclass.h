class Log
{
	FILE *fp;
	bool logOk;

public:
	//constructor
	Log();

    
	//Log initialization
	void init(const char * pfileName);

    
	//close the file
	void close();


    // A critical section is required to protect 
	//the file writing function in multithreading programms
	void write(char *pType, char *pMsg, char *pFileName, int lineNo);


    //Destructor
	~Log();

};