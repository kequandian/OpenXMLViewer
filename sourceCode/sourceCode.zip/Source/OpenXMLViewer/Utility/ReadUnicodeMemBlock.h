#ifndef _FILESYSUTIL_
#define _FILESYSUTIL_

#include "iostream"
#include "fstream"
#include"string.h"
#include"sstream"
#include"stdlib.h"
#include"log.h"
#include "sys/stat.h"

#include "stdio.h"
#include "fcntl.h"

#ifdef _WIN32
#include"direct.h"
//used only for delete_directory
#include <tchar.h>
#include <windows.h>
#include <io.h>
#include <sys/stat.h>
#include <shellapi.h>
#endif

#define SUCCESS 0;
#define FAILURE -1;

#ifdef _WIN32
#include"direct.h"
#include"windows.h"
#endif


using namespace std;


//ReadUnicodeMemBlock class declaration
class FileSystemUtil
{
	//Used for .txt, .bin  file
	wfstream file_stream;
	wchar_t *file_content;
	fstream::pos_type file_current_size;
	std::string command;

	//Used for .docx binary file
	FILE *fr;
	FILE *fw;
	char * memblock;
	long sourcelength;

	//declaration for delete directory
	#ifdef _WIN32
	int len;
	TCHAR *pszFrom;
	SHFILEOPSTRUCT fileop;
	int ret;
    bool noRecycleBin;
    #endif

public:

	//constructor
	FileSystemUtil();


	//Create a directory by taking path of the directory as an argument
	//and returns 0 for success and -1 for failure
	int create_directory(string path);


    //Delete the directory by taking path of the directory as an argument
	//Returns 0 for success and -1 for failure
	int delete_directory(string path);


    // Method read the file passed as an argument, allocate space 
	//in the memory block and store the contents of that file into 
	//the memory , returns 0 for success and -1 for failure
	int store_file_memory( string filepath );


	//Get the address of the memory block
	wchar_t * getmemblockaddress();


	//Store the contents of memory into another new file.
	//Takes memory block address and file path as argument.
	//Returns 0 for success and -1 for failure
	int store_memory_file(wchar_t *ptr_memblock, string filepath_new) ;

 
	//copy at time using FILE
	int copy_file(string fread, string fwrite);


	//Destructor
   ~FileSystemUtil();

};
#endif