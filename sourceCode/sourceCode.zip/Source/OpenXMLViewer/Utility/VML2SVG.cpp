#include "VML2SVG.h"
#include "XMLHelper.h"
#include <math.h>
#include <map>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;
using namespace Utility;

DOMElement *text_parent_node;

VML2SVG::VML2SVG()				
{
}

VML2SVG::~VML2SVG()
{
}

//Convert from VML to SVG
//*vml should contain a w:pict element at root level
void VML2SVG::ConvertVML2SVG(xercesc::DOMDocument* doc, map<const XMLCh*, const XMLCh*> *imgMap)
{
	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;
	imageMap = (*imgMap);
	XMLCh *rootname = XMLString::transcode("svg");
	XMLCh *w_pict = XMLString::transcode("w:pict");
	DOMElement *vml = NULL;
	DOMElement *svg = NULL;
	DOMElement *div = NULL;
	//DOMElement *line_break = NULL;
	DOMElement *shapetype = NULL;

	try
	{
		DOMNodeList *shapetype_list = doc->getElementsByTagName(XMLString::transcode("v:shapetype"));
		int shapetype_count = shapetype_list->getLength();

		//Adding shape type to map
		for(int i = 0; i < shapetype_count; i++)
		{
			//item(i) since the node is not replaced.
			shapetype = dynamic_cast<DOMElement*>(shapetype_list->item(i));

			shapetypeMap.insert(std::pair<string, DOMElement*>(helper->convertToString(helper->GetAttributeValue(shapetype, "id")),dynamic_cast<DOMElement*>(shapetype)));
		} 

		DOMNodeList *vmllist = doc->getElementsByTagName(XMLString::transcode("w:pict"));
		int vmlcount = vmllist->getLength();

		for(int i = 0; i < vmlcount; i++)
		{	
			//line_break = doc->createElement(XMLString::transcode("br"));
			div = doc->createElement(XMLString::transcode("div"));
			//item(0) since the node is replaced dynamically at the end of the loop.
			vml = dynamic_cast<DOMElement*>(vmllist->item(0));
			svg = doc->createElement(XMLString::transcode("svg"));

			styleHelper.WriteAttribute(svg, "xmlns:xlink", "http://www.w3.org/1999/xlink");

			//check if w:pict node is the root
			if (vml != NULL)
			{
				if (XMLString::compareString(vml->getNodeName(), w_pict) == 0)
				{
					if (vml->hasChildNodes())
					{ 
						ProcessVMLNode(dynamic_cast<DOMElement*>(vml->getFirstChild()), svg);
					}
				}
				else
					return ;				
			}
			else				
				return ;

			DOMElement *parent = dynamic_cast<DOMElement*>(vml->getParentNode());		

			parent->appendChild(div);
			// to insert line break, let it be commented.
			//styleHelper.WriteAttribute(line_break, "xmlns", "http://www.w3.org/1999/xhtml");
			//parent->appendChild(line_break);
			parent->removeChild(vml);

			div->appendChild(svg);
			//div->appendChild(line_break);
		}
	}
	catch(exception)
	{
		cout<<"Exception occured"<<endl;
	}	
	XMLString::release((XMLCh**)&rootname);
	XMLString::release((XMLCh**)&w_pict);
}
//Process the VML node and convert to SVG
void VML2SVG::ProcessVMLNode(DOMElement* vml, DOMElement *svg)
{
	DOMNamedNodeMap *vml_attr_map = vml->getAttributes();

	if(XMLString::compareString(vml->getNodeName(), XMLString::transcode("v:rect")) == 0)
	{
		InitializeRectNode(vml, svg, vml_attr_map);	
	}

	if(XMLString::compareString(vml->getNodeName(), XMLString::transcode("v:group")) == 0)
	{
		InitializeGroupNode(vml,svg,vml_attr_map);		
	}		

	if(XMLString::compareString(vml->getNodeName(), XMLString::transcode("v:shape")) == 0)
	{		
		InitializeShapeNode(vml, svg, vml_attr_map);		
	}

	if(XMLString::compareString(vml->getNodeName(), XMLString::transcode("v:stroke")) == 0)
	{	
		HandleStrokeNode(vml_attr_map, vml, svg);
	}

	if(XMLString::compareString(vml->getNodeName(), XMLString::transcode("v:textbox")) == 0)
	{
		InitializeTextBoxNode(vml, svg, vml_attr_map, vml->getParentNode()->getAttributes());
	}

	if(XMLString::compareString(vml->getNodeName(), XMLString::transcode("v:line")) == 0)
	{
		InitializeLineNode(vml, svg, vml_attr_map);
	}

	if(XMLString::compareString(vml->getNodeName(), XMLString::transcode("v:roundrect")) == 0)
	{			
		InitializeRoundRectNode(vml, svg, vml_attr_map);
	}

	if(XMLString::compareString(vml->getNodeName(), XMLString::transcode("v:oval")) == 0)
	{				
		InitializeOvalNode(vml, svg, vml_attr_map);
	}	

	DOMNode *sibling = vml->getNextSibling();

	if(sibling != NULL)
	{
		ProcessVMLNode(dynamic_cast<DOMElement*>(sibling), svg);
	}
	return;
}

DOMElement * VML2SVG::HandleImageFill(DOMElement* parent_node, DOMElement* node, DOMElement *svg, 
									  DOMNamedNodeMap *vml_attr_map)
{
	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;
	ColorHelper colorHelper;
	DOMNamedNodeMap *attr_map = node->getAttributes();

	if(!node->hasAttributes())
	{
		return NULL;
	}

	if(helper->GetAttributeValue(attr_map, "on") != NULL)
	{
		XMLCh * flag_x = helper->GetAttributeValue(attr_map, "on");
		if(((helper->convertToString(flag_x)).compare("false"))||((helper->convertToString(flag_x)).compare("0")))
		{
			return NULL;
		}
	}	

	if((helper->GetAttributeValue(attr_map, "color") != NULL && XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "filled"), XMLString::transcode("f")) != 0))
	{
		parent_node->setAttribute(XMLString::transcode("fill"), colorHelper.GetColor(helper->GetAttributeValue(attr_map, "color")));
	}

	if(helper->GetAttributeValue(attr_map, "opacity") != NULL)
	{
		float f_opacity = helper->convertToFloat(helper->GetAttributeValue(attr_map, "opacity"));

		if(f_opacity <= 1.0)
		{
			parent_node->setAttribute(XMLString::transcode("fill-opacity"), helper->GetAttributeValue(attr_map, "opacity"));
		}
		else
		{
			parent_node->setAttribute(XMLString::transcode("fill-opacity"), XMLString::transcode("0.5"));
		}
	}

	if((int)imageMap.size() <= 0 )
	{
		return NULL;

	}
	else if(helper->GetAttributeValue(node, "r:id") != NULL)
	{
		DOMElement *defs_node = svg->getOwnerDocument()->createElement(XMLString::transcode("defs"));
		DOMElement *pattern_node = svg->getOwnerDocument()->createElement(XMLString::transcode("pattern"));
		styleHelper.WriteAttribute(pattern_node, "id", helper->GetAttributeValue(vml_attr_map, "id"));
		styleHelper.WriteAttribute(pattern_node, "patternUnits", "userSpaceOnUse");
		map<string, XMLCh*> styleMap;
		string viewbox;

		if(helper->GetAttributeValue(vml_attr_map, "style") != NULL)
		{
			styleHelper.ParseStyle(helper->GetAttributeValue(vml_attr_map, "style"), &styleMap);
		}
		if(helper->GetAttributeValue(vml_attr_map, "type") == NULL)
		{
			float height = helper->convertToFloat(styleHelper.GetHeightfromStyle(&styleMap)) * 2 + 20;
			float width = helper->convertToFloat(styleHelper.GetWidthfromStyle(&styleMap)) * 2 + 20;

			styleHelper.WriteAttribute(pattern_node, "height", helper->convertToXMLCh(helper->convertToString(height).append("pt")));
			styleHelper.WriteAttribute(pattern_node, "width", helper->convertToXMLCh(helper->convertToString(width).append("pt")));
			if(XMLString::compareString(XMLString::transcode("ellipse"), (parent_node->getNodeName())) == 0)
			{
				styleHelper.WriteAttribute(pattern_node, "x", styleHelper.GetXcoordinatefromStyle(&styleMap));
				styleHelper.WriteAttribute(pattern_node, "y", styleHelper.GetYcoordinatefromStyle(&styleMap));
			}
			//viewBox can be added when the image needs to be strecthed

			/*viewbox.append(helper->convertToString(helper->convertToFloat(styleHelper.GetWidthfromStyle(&styleMap)) / 4)).append(" ").append(helper->convertToString(helper->convertToFloat(styleHelper.GetHeightfromStyle(&styleMap)) / 4)).append(" ");
			viewbox.append(helper->convertToString(helper->convertToFloat(styleHelper.GetWidthfromStyle(&styleMap)) / 2)).append(" ").append(helper->convertToString(helper->convertToFloat(styleHelper.GetHeightfromStyle(&styleMap)) / 2));
			styleHelper.WriteAttribute(pattern_node, "viewBox", helper->convertToXMLCh(viewbox));*/
		}
		else
		{
			styleHelper.WriteAttribute(pattern_node, "height", XMLString::transcode("21600pt"));
			styleHelper.WriteAttribute(pattern_node, "width", XMLString::transcode("21600pt"));

		}
		DOMElement *img_node = svg->getOwnerDocument()->createElement(XMLString::transcode("image"));
		const XMLCh* imgaddr = NULL;
		img_node = SetNodeAttributes(vml_attr_map, img_node, node);

		styleHelper.WriteAttribute(img_node, "id", helper->GetAttributeValue(node, "r:id"));

		map<const XMLCh*, const XMLCh*>::iterator iter = imageMap.begin();

		while (iter != imageMap.end())	
		{ 
			if (XMLString::compareString((iter->first), helper->GetAttributeValue(node, "r:id")) == 0)
			{
				imgaddr = iter->second;
				break;
			}
			iter++;
		}
		string src = "word/";
		if(imgaddr != NULL)
		{
			src  = src.append(helper->convertToString(imgaddr));
		}
		styleHelper.WriteAttribute(img_node, "xlink:href", helper->convertToXMLCh(src));

		if(helper->GetAttributeValue(vml_attr_map, "type") != NULL)
		{
			styleHelper.WriteAttribute(img_node, "height", XMLString::transcode("21600pt"));
			styleHelper.WriteAttribute(img_node, "width", XMLString::transcode("21600pt"));
		}

		if(node->hasChildNodes())
		{ 
			ProcessVMLNode(dynamic_cast<DOMElement*>(node->getFirstChild()), img_node);
		}
		pattern_node->appendChild(img_node);
		defs_node->appendChild(pattern_node);

		return defs_node;
	}
	return NULL;
}

DOMElement * VML2SVG::HandleImageData(DOMElement* node, DOMElement *svg, DOMNamedNodeMap *vml_attr_map)
{
	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;

	DOMElement *parent_svg = svg->getOwnerDocument()->createElement(XMLString::transcode("svg"));
	styleHelper.WriteAttribute(parent_svg, "xmlns", "http://www.w3.org/2000/svg");
	styleHelper.WriteAttribute(parent_svg, "version", "1.1");
	styleHelper.WriteAttribute(parent_svg, "preserveAspectRatio", "none");//xMinYMin meet

	DOMElement *img_node = svg->getOwnerDocument()->createElement(XMLString::transcode("image"));

	map<string, XMLCh*> styleMap;

	if(helper->GetAttributeValue(vml_attr_map, "style") != NULL)
	{
		styleHelper.ParseStyle(helper->GetAttributeValue(vml_attr_map, "style"), &styleMap);
		styleHelper.WriteAttribute(parent_svg, "style", helper->GetAttributeValue(vml_attr_map, "style"));

		if(styleHelper.GetHeightfromStyle(&styleMap) != NULL)
		{
			styleHelper.WriteAttribute(img_node, "height", styleHelper.GetHeightfromStyle(&styleMap));
		}
		if(styleHelper.GetWidthfromStyle(&styleMap) != NULL)
		{
			styleHelper.WriteAttribute(img_node, "width", styleHelper.GetWidthfromStyle(&styleMap));
		}
		if(styleHelper.GetXcoordinatefromStyle(&styleMap) != NULL)
		{
			styleHelper.WriteAttribute(img_node, "x", styleHelper.GetXcoordinatefromStyle(&styleMap));
		}
		if(styleHelper.GetYcoordinatefromStyle(&styleMap) != NULL)
		{
			styleHelper.WriteAttribute(img_node, "y", styleHelper.GetYcoordinatefromStyle(&styleMap));
		}
	}

	const XMLCh* imgaddr = NULL;
	styleHelper.WriteAttribute(img_node, "id", helper->GetAttributeValue(node, "r:id"));
	map<const XMLCh*, const XMLCh*>::iterator iter = imageMap.begin();

	while (iter != imageMap.end())	
	{ 
		if (XMLString::compareString((iter->first), helper->GetAttributeValue(node, "r:id")) == 0)
		{
			imgaddr = iter->second;
			break;
		}
		iter++;
	}

	string src = "word/";
	if(imgaddr != NULL)
	{
		src  = src.append(helper->convertToString(imgaddr));
	}
	styleHelper.WriteAttribute(img_node, "xlink:href", helper->convertToXMLCh(src));

	parent_svg->appendChild(img_node);
	return parent_svg;

}
void  VML2SVG::InitializeRectNode(DOMElement* node, DOMElement *svg, DOMNamedNodeMap *vml_attr_map )
{
	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;

	DOMElement *parent_svg = svg->getOwnerDocument()->createElement(XMLString::transcode("svg"));

	string translate="translate(";

	parent_svg = SetParentSvgNodeAttr(parent_svg, node);


	DOMElement *g = svg->getOwnerDocument()->createElement(XMLString::transcode("g"));
	DOMElement *rect_node = svg->getOwnerDocument()->createElement(XMLString::transcode("rect"));

	rect_node = SetNodeAttributes(vml_attr_map,  rect_node, node);

	text_parent_node = svg;

	if(node->hasChildNodes())
	{ 		
		const XMLCh * nodename = (node->getFirstChild())->getNodeName();

		if(XMLString::compareString(nodename, XMLString::transcode("v:fill")) == 0)
		{
			DOMElement *img_node = svg->getOwnerDocument()->createElement(XMLString::transcode("image"));
			img_node = HandleImageFill(rect_node, dynamic_cast<DOMElement*>(node->getFirstChild()), svg, vml_attr_map); 
			if(img_node != NULL)
			{
				parent_svg->appendChild(img_node);

				string url = "url(#";
				url.append(helper->convertToString(helper->GetAttributeValue(vml_attr_map, "id"))).append(")");				
				rect_node->setAttribute(XMLString::transcode("fill"), helper->convertToXMLCh(url));
			}
		}

		ProcessVMLNode(dynamic_cast<DOMElement*>(node->getFirstChild()), rect_node);
	}

	float f_x = helper->convertToFloat(helper->GetAttributeValue(parent_svg, "x")) * 1.333;
	float f_y = helper->convertToFloat(helper->GetAttributeValue(parent_svg, "y")) * 1.333;

	translate.append(helper->convertToString(f_x)).append(" ");
	translate.append(helper->convertToString(f_y)).append(")");

	if (helper->convertToString(text_parent_node->getNodeName()) == "text")
	{
		SetTextboxParentNode(svg, parent_svg, text_parent_node, rect_node, vml_attr_map);
		/*g->appendChild(rect_node);
		g->appendChild(text_parent_node);
		parent_svg->appendChild(g);
		svg->appendChild(parent_svg);*/

		return;
	}
	parent_svg->appendChild(rect_node);
	svg->appendChild(parent_svg);
}

void  VML2SVG::InitializeGroupNode(DOMElement* node, DOMElement *svg, DOMNamedNodeMap *vml_attr_map)
{
	XMLHelper *helper = XMLHelper::getInstance();	

	DOMElement *group_node = svg->getOwnerDocument()->createElement(XMLString::transcode("g"));
	DOMElement *parent_svg = svg->getOwnerDocument()->createElement(XMLString::transcode("svg"));

	parent_svg = SetParentSvgNodeAttr(parent_svg, node);

	string viewbox = GetViewbox(vml_attr_map);

	if(viewbox.size() > 0)
	{
		StyleHelper styleHelper;
		styleHelper.WriteAttribute(parent_svg, "viewBox", const_cast<char*>(viewbox.c_str()));
	}

	if(node->hasChildNodes())
	{
		ProcessVMLNode(dynamic_cast<DOMElement*>(node->getFirstChild()), group_node);	
	}

	parent_svg->appendChild(group_node);	
	svg->appendChild(parent_svg);
}

void  VML2SVG::InitializeShapeNode(DOMElement* node, DOMElement *svg, DOMNamedNodeMap *vml_attr_map )
{
	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;

	DOMNodeList* child_list = node->getChildNodes();

	for(int i = 0; i < child_list->getLength(); i++)
	{
		if(XMLString::compareString(XMLString::transcode("v:imagedata"), (child_list->item(i))->getNodeName()) == 0)
		{
			DOMElement *imagedata = NULL;
			imagedata = HandleImageData(dynamic_cast<DOMElement*>(child_list->item(i)), svg, vml_attr_map);			
			svg->appendChild(imagedata);
			return ;
		}
	}

	DOMElement *shape_node = svg->getOwnerDocument()->createElement(XMLString::transcode("path"));

	map<string, XMLCh*> styleMap;
	styleHelper.ParseStyle(helper->GetAttributeValue(vml_attr_map, "style"), &styleMap);

	//Check if a shapetype has been referenced
	DOMElement *shapetype = NULL;
	if(helper->GetAttributeValue(vml_attr_map, "type") != NULL)
	{
		string type_s = helper->convertToString(helper->GetAttributeValue(vml_attr_map, "type"));
		type_s = type_s.substr(1, type_s.size() - 1);

		map<string, DOMElement*>::iterator iter = shapetypeMap.find(type_s);

		//check if type is present in the map
		if(iter == shapetypeMap.end())
		{		
			return ;
		}

		shapetype = iter->second ;

		if(shapetype != NULL)
		{
			DOMNamedNodeMap *shapetype_attr_list = shapetype->getAttributes();
			InitializeShapeTypeNode(shapetype, svg, node, shapetype_attr_list); 
		}
	}
	else
	{
		//Get child nodes and process	
		DOMElement *parent_svg = svg->getOwnerDocument()->createElement(XMLString::transcode("svg"));
		parent_svg = SetParentSvgNodeAttr(parent_svg, node, vml_attr_map);

		shape_node = SetNodeAttributes(vml_attr_map, shape_node, node);

		map<string, FormulaContainer> formulae;
		DOMNamedNodeMap *shape_attr_map = node->getAttributes();
		DOMNamedNodeMap *shapetype_attr_list= NULL;
		XMLCh *svg_path = InterpretPath(helper->GetAttributeValue(vml_attr_map, "path"), shapetype_attr_list, shape_attr_map, formulae);		
		styleHelper.WriteAttribute(shape_node, "d", svg_path);	

		if(node->hasChildNodes())
		{
			if(XMLString::compareString((node->getFirstChild())->getNodeName(), XMLString::transcode("v:fill")) == 0)
			{
				DOMElement *img_node = svg->getOwnerDocument()->createElement(XMLString::transcode("image"));
				img_node = HandleImageFill(shape_node, dynamic_cast<DOMElement*>(node->getFirstChild()), svg, vml_attr_map); 
				if(img_node != NULL)
				{
					parent_svg->appendChild(img_node);

					string url = "url(#";
					url.append(helper->convertToString(helper->GetAttributeValue(vml_attr_map, "id"))).append(")");
					shape_node->setAttribute(XMLString::transcode("fill"), helper->convertToXMLCh(url));
				}
			}
			ProcessVMLNode(dynamic_cast<DOMElement*>(node->getFirstChild()), svg);
		}
		parent_svg->appendChild(shape_node);
		svg->appendChild(parent_svg);
	}	
}

void  VML2SVG::InitializeOvalNode(DOMElement* node, DOMElement *svg, DOMNamedNodeMap *vml_attr_map)
{
	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;

	DOMElement *parent_svg = svg->getOwnerDocument()->createElement(XMLString::transcode("svg"));
	parent_svg = SetParentSvgNodeAttr(parent_svg, node);

	DOMElement *g_node = svg->getOwnerDocument()->createElement(XMLString::transcode("g"));
	DOMElement *ellipse_node  = svg->getOwnerDocument()->createElement(XMLString::transcode("ellipse"));

	ellipse_node = SetNodeAttributes(vml_attr_map,  ellipse_node, node);

	text_parent_node = svg;

	if(node->hasChildNodes())
	{ 
		if(XMLString::compareString((node->getFirstChild())->getNodeName(), XMLString::transcode("v:fill")) == 0)
		{
			DOMElement *img_node = svg->getOwnerDocument()->createElement(XMLString::transcode("image"));
			img_node = HandleImageFill(ellipse_node, dynamic_cast<DOMElement*>(node->getFirstChild()), svg, vml_attr_map); 
			if(img_node != NULL)
			{
				parent_svg->appendChild(img_node);

				string url = "url(#";
				url.append(helper->convertToString(helper->GetAttributeValue(vml_attr_map, "id"))).append(")");
				ellipse_node->setAttribute(XMLString::transcode("fill"), helper->convertToXMLCh(url));
			}
		}
		ProcessVMLNode(dynamic_cast<DOMElement*>(node->getFirstChild()), ellipse_node);
	}

	float f_cx = helper->convertToFloat(helper->GetAttributeValue(ellipse_node, "cx")) * 1.33;
	float f_cy = helper->convertToFloat(helper->GetAttributeValue(ellipse_node, "cy")) * 1.33;

	string translate="translate(";
	translate.append(helper->convertToString(f_cx)).append(" ");
	translate.append(helper->convertToString(f_cy)).append(")");

	if(helper->convertToString(ellipse_node->getAttribute(XMLString::transcode("transform"))) != "")
	{
		styleHelper.WriteAttribute(ellipse_node, "cx", helper->convertToXMLCh("0"));
		styleHelper.WriteAttribute(ellipse_node, "cy", helper->convertToXMLCh("0"));
		styleHelper.WriteAttribute(g_node, "transform", helper->convertToXMLCh(translate));
	}

	if (helper->convertToString(text_parent_node->getNodeName()) == "text")
	{
		SetTextboxParentNode(svg, parent_svg, text_parent_node, ellipse_node, vml_attr_map);
		parent_svg->appendChild(ellipse_node);
		parent_svg->appendChild(text_parent_node);
		svg->appendChild(parent_svg);
		return;
	}
	if(helper->convertToString(ellipse_node->getAttribute(XMLString::transcode("transform"))) != "")
	{
		g_node->appendChild(ellipse_node);
		parent_svg->appendChild(g_node);
		svg->appendChild(parent_svg);
	}
	else
	{
		parent_svg->appendChild(ellipse_node);
		svg->appendChild(parent_svg);
	}
}

void  VML2SVG::InitializeRoundRectNode(DOMElement* node, DOMElement *svg, DOMNamedNodeMap *vml_attr_map)
{
	StyleHelper styleHelper;
	XMLHelper *helper = XMLHelper::getInstance();

	DOMElement *parent_svg = svg->getOwnerDocument()->createElement(XMLString::transcode("svg"));
	parent_svg = SetParentSvgNodeAttr(parent_svg, node);

	DOMElement *g_node = svg->getOwnerDocument()->createElement(XMLString::transcode("g"));
	DOMElement *roundRect_node = svg->getOwnerDocument()->createElement(XMLString::transcode("rect"));

	roundRect_node = SetNodeAttributes(vml_attr_map,  roundRect_node, node);
	styleHelper.WriteAttribute(roundRect_node, "ry", XMLString::transcode("20%"));

	text_parent_node = parent_svg;

	if(node->hasChildNodes())
	{ 		
		if(XMLString::compareString((node->getFirstChild())->getNodeName(), XMLString::transcode("v:fill")) == 0)
		{
			DOMElement *img_node = svg->getOwnerDocument()->createElement(XMLString::transcode("image"));
			img_node = HandleImageFill(roundRect_node, dynamic_cast<DOMElement*>(node->getFirstChild()), svg, vml_attr_map); 
			if(img_node != NULL)
			{
				parent_svg->appendChild(img_node);

				string url = "url(#";
				url.append(helper->convertToString(helper->GetAttributeValue(vml_attr_map, "id"))).append(")");
				roundRect_node->setAttribute(XMLString::transcode("fill"), helper->convertToXMLCh(url));
			}
		}
		ProcessVMLNode(dynamic_cast<DOMElement*>(node->getFirstChild()), roundRect_node);
	}

	float f_x = helper->convertToFloat(helper->GetAttributeValue(roundRect_node, "x")) * 1.333;
	float f_y = helper->convertToFloat(helper->GetAttributeValue(roundRect_node, "y")) * 1.333;

	string translate="translate(";
	translate.append(helper->convertToString(f_x)).append(" ");
	translate.append(helper->convertToString(f_y)).append(")");

	string parent_height = helper->convertToString(f_y).append("pt");

	if (helper->convertToString(text_parent_node->getNodeName()) == "text")
	{
		SetTextboxParentNode(svg, parent_svg, text_parent_node, roundRect_node, vml_attr_map);
		/*g->appendChild(roundRect_node);
		g->appendChild(text_parent_node);
		parent_svg->appendChild(g);
		svg->appendChild(parent_svg);*/

		return;
	}

	parent_svg->appendChild(roundRect_node);
	svg->appendChild(parent_svg);
}

void  VML2SVG::InitializeTextBoxNode(DOMElement* node, DOMElement *svg, DOMNamedNodeMap *vml_attr_map, DOMNamedNodeMap *parent_attr_map)
{
	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;

	DOMElement *textbox_node = svg->getOwnerDocument()->createElement(XMLString::transcode("text"));
	DOMNode *par_node = ((node->getParentNode())->getParentNode());

	map<string, XMLCh*> styleMap;
	if(helper->GetAttributeValue(parent_attr_map, "style") != NULL)
	{
		styleHelper.ParseStyle(helper->GetAttributeValue(parent_attr_map, "style"), &styleMap);
	}

	XMLCh *x_X = styleHelper.GetXcoordinatefromStyle(&styleMap);
	XMLCh *y_Y = styleHelper.GetYcoordinatefromStyle(&styleMap);

	//Get the center of the parent node
	if(x_X != NULL)
	{
		if(styleHelper.GetWidthfromStyle(&styleMap) != NULL)
		{
			float x_f = helper->convertToFloat(x_X);
			x_f = x_f + (helper->convertToFloat(styleHelper.GetWidthfromStyle(&styleMap))) / 5;
			x_X = helper->convertToXMLCh(x_f);
		}
		styleHelper.WriteAttribute(textbox_node, "x", x_X);
	}

	if(y_Y != NULL)
	{
		if(styleHelper.GetWidthfromStyle(&styleMap) != NULL)
		{
			float y_f = helper->convertToFloat(y_Y);

			y_f = y_f + helper->convertToFloat(styleHelper.GetWidthfromStyle(&styleMap)) / 5;
			y_Y = helper->convertToXMLCh(y_f);
		}
		styleHelper.WriteAttribute(textbox_node, "y", y_Y);
	}

	//Get the textbox text

	vector<DOMElement*> *b_txbxNodes = helper->ParseMinimalXPath(svg->getOwnerDocument(), (svg->getOwnerDocument())->getDocumentElement() ,"//w:body/w:p");
	vector<DOMElement*>::iterator iter = b_txbxNodes->begin();

	DOMElement *b_txbxNode = NULL;
	DOMElement *body_txbxNode = NULL;
	DOMNode *pNode = NULL;

	if(node->getTextContent() != NULL)
	{
		int max_len = helper->convertToString(node->getTextContent()).length();
		int count = 0;
		string text_substr; 
		const XMLCh *s_substr;
		const XMLCh	*subs;
		float f_x = 0;
		float f_y = 0;
		int width_i = helper->convertToInt(svg->getAttribute(XMLString::transcode("width")));
		DOMElement *tspan_node = NULL; // tspan_node[15]

		styleHelper.WriteAttribute(textbox_node, "rotate", helper->GetAttributeValue(vml_attr_map, "MSO-rotate"));
		styleHelper.WriteAttribute(textbox_node, "textlength", helper->GetAttributeValue(vml_attr_map, "textLength"));

		if (x_X != NULL){
			if(helper->convertToString(par_node->getNodeName()) != "v:group")
			{				
				if (XMLString::compareString((node->getParentNode())->getNodeName(), XMLString::transcode("v:roundrect")) == 0)
				{					
					f_x = helper->convertToFloat(styleHelper.GetXcoordinatefromStyle(&styleMap))* 0.05;
				}

				else
				{
					f_x = helper->convertToFloat(x_X) * 0.1;
				}
			}
			else
			{
				f_x = helper->convertToFloat((styleMap)["left"]) / 10;
			}
		}

		if (y_Y != NULL)
		{
			if(helper->convertToString(par_node->getNodeName()) != "v:group")
			{				
				f_y = helper->convertToFloat(y_Y);
			}
			else
			{
				f_y = helper->convertToFloat((styleMap)["top"]) / 10;
			}
		}

		if ((XMLString::compareString((node->getParentNode())->getNodeName(), XMLString::transcode("v:oval")) == 0) && (x_X != NULL) && (y_Y != NULL))
		{
			if(helper->convertToString(par_node->getNodeName()) != "v:group")
			{
				f_x = helper->convertToFloat(x_X) * 1.33;
				f_y = helper->convertToFloat(y_Y) * 1.3;
			}
			else
			{
				f_x = helper->convertToFloat(helper->GetAttributeValue(svg, "cx")) * 0.8;
				f_y = helper->convertToFloat(helper->GetAttributeValue(svg, "cy"));
			}
		}

		if (((XMLString::compareString((node->getParentNode())->getNodeName(), XMLString::transcode("v:shape")) == 0) || (XMLString::compareString((node->getParentNode())->getNodeName(), XMLString::transcode("v:shape")) == 0)) && (x_X != NULL) && (y_Y != NULL))
		{
			f_x = (helper->convertToFloat(helper->GetAttributeValue(svg, "width")) / 3);
			
			if(helper->convertToInt(styleHelper.GetHeightfromStyle(&styleMap)) > 0)
			{
				f_y = (helper->convertToFloat(styleHelper.GetHeightfromStyle(&styleMap)) / 2) + 15;
			}
			else
			{
				f_y = helper->convertToFloat(XMLString::transcode(svg->getAttribute(XMLString::transcode("height"))))/2 + 15;
			}	
		}

		// For multiple paragraphs
		if (b_txbxNodes->size() > 0)
		{
			vector<DOMElement*> *pNodes = helper->ParseMinimalXPath(svg->getOwnerDocument(), node ,"//w:txbxContent/w:p"); 			
			vector<DOMElement*>::iterator p_iter = pNodes->begin();

			for(int i=0; i < b_txbxNodes->size(); i++)
			{	
				b_txbxNode = helper->SelectSingleNode(svg->getOwnerDocument(), iter[i], "//w:txbxContent");

				if (b_txbxNode != NULL)
				{
					vector<DOMElement*> *pNodes = helper->ParseMinimalXPath(svg->getOwnerDocument(), node ,"//w:txbxContent/w:p");				
					vector<DOMElement*>::iterator p_iter = pNodes->begin();

					if (pNodes->size() > 0)
					{
						pNode = helper->SelectSingleNode(svg->getOwnerDocument(), b_txbxNode, "//w:p");

						int j = 0 ;

						while(j < pNodes->size())
						{							
							if(j > 0)								
							{
								pNode = pNode->getNextSibling();
							}

							pNode = p_iter[j];
							string str = " ";
							str = helper->convertToString(pNode->getTextContent());
							int len = 0;

							// get length of the string in the row
							int strlen = (int)str.length();
							if(strlen > 0)
							{
								if ((strlen * 5) > width_i)
								{
									//For paragraph with multiple lines of text
									while ((strlen * 5) > (float)width_i)
									{
										text_substr  = str.substr(len, width_i / 5);
										strlen -= width_i / 5;
										len += width_i / 5;

										s_substr = helper->convertToXMLCh(text_substr);
										tspan_node = svg->getOwnerDocument()->createElement(XMLString::transcode("tspan"));

										tspan_node->setTextContent(s_substr);
										textbox_node->appendChild(tspan_node);

										x_X = helper->convertToXMLCh(f_x);
										y_Y = helper->convertToXMLCh(f_y);

										styleHelper.WriteAttribute(tspan_node, "x", x_X);
										styleHelper.WriteAttribute(tspan_node, "y", y_Y);

										f_y += 15; 
									}
									text_substr = str.substr(len, str.length());
									s_substr = helper->convertToXMLCh(text_substr);
									tspan_node = svg->getOwnerDocument()->createElement(XMLString::transcode("tspan"));

									tspan_node->setTextContent(s_substr);
									textbox_node->appendChild(tspan_node);

									x_X = helper->convertToXMLCh(f_x);
									y_Y = helper->convertToXMLCh(f_y);

									styleHelper.WriteAttribute(tspan_node, "x", x_X);
									styleHelper.WriteAttribute(tspan_node, "y", y_Y);

									f_y += 15; 
								}

								else
								{
									s_substr = helper->convertToXMLCh(str);

									tspan_node = svg->getOwnerDocument()->createElement(XMLString::transcode("tspan"));
									tspan_node->setTextContent(s_substr);
									textbox_node->appendChild(tspan_node);

									if (x_X != NULL)
									{
										x_X = helper->convertToXMLCh(f_x);
									}

									if(y_Y != NULL)
									{
										y_Y = helper->convertToXMLCh(f_y);
									}

									styleHelper.WriteAttribute(tspan_node, "x", x_X);
									styleHelper.WriteAttribute(tspan_node, "y", y_Y);
								}
							}
							f_y += 15;
							j++;
						}
						count++;
					}
					break;
				}					
			}		
		}	
		if(count == 0)
		{
			textbox_node->setTextContent(node->getTextContent());
			styleHelper.WriteAttribute(textbox_node, "text-anchor", "middle");
		}
	}
	text_parent_node = textbox_node;
}


DOMElement* VML2SVG::InitializeLineNode(DOMElement* node, DOMElement *svg, DOMNamedNodeMap *vml_attr_map)
{
	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;
	ColorHelper colorHelper;


	DOMElement *line_node = NULL;
	DOMElement *defs = svg->getOwnerDocument()->createElement(XMLString::transcode("defs"));
	DOMElement *line_marker_node = svg->getOwnerDocument()->createElement(XMLString::transcode("marker"));

	string id_end = "ArrowEnd";


	if(helper->GetAttributeValue(vml_attr_map, "id") != NULL)	
	{
		id_end.append(helper->convertToString(helper->GetAttributeValue(vml_attr_map, "id")));
	}
	else
	{
		id_end.append("1");
	}
	styleHelper.WriteAttribute(line_marker_node, "id", helper->convertToXMLCh(id_end));
	styleHelper.WriteAttribute(line_marker_node, "viewBox", XMLString::transcode("0 0 10 10"));//0 0 10 10 //0 0 100 100
	styleHelper.WriteAttribute(line_marker_node, "refX", XMLString::transcode("2"));//1 //10
	styleHelper.WriteAttribute(line_marker_node, "refY", XMLString::transcode("5"));//5 //50
	styleHelper.WriteAttribute(line_marker_node, "markerWidth", XMLString::transcode("10"));//10 //50
	styleHelper.WriteAttribute(line_marker_node, "markerHeight", XMLString::transcode("10"));//10 //50
	styleHelper.WriteAttribute(line_marker_node, "orient", XMLString::transcode("auto"));
	styleHelper.WriteAttribute(line_marker_node, "markerUnits", XMLString::transcode("strokeWidth"));
	DOMElement *arrow_path_node = svg->getOwnerDocument()->createElement(XMLString::transcode("path"));

	styleHelper.WriteAttribute(arrow_path_node, "d", XMLString::transcode("M 0,0 L 5,5 0,10 z"));//M 0,0 L 5,5 0,10 Z  //M 0,0 L 50,50 0,100 Z

	if((helper->GetAttributeValue(vml_attr_map, "strokecolor") != NULL) && XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "stroked"), XMLString::transcode("f")) != 0)
	{
		styleHelper.WriteAttribute(arrow_path_node, "fill", colorHelper.GetColor(helper->GetAttributeValue(vml_attr_map, "strokecolor")));
	}
	else
	{
		styleHelper.WriteAttribute(arrow_path_node, "fill", XMLString::transcode("black"));
	}

	//styleHelper.WriteAttribute(arrow_path_node, "fill", XMLString::transcode("black"));

	DOMElement *defs2 = svg->getOwnerDocument()->createElement(XMLString::transcode("defs"));
	DOMElement *line_marker_node2 = svg->getOwnerDocument()->createElement(XMLString::transcode("marker"));

	string id_start = "ArrowStart";

	if(helper->GetAttributeValue(vml_attr_map, "id") != NULL)	
	{
		id_start.append(helper->convertToString(helper->GetAttributeValue(vml_attr_map, "id")));
	}
	else
	{
		id_start.append("1");
	}

	styleHelper.WriteAttribute(line_marker_node2, "id", helper->convertToXMLCh(id_start));
	styleHelper.WriteAttribute(line_marker_node2, "viewBox", XMLString::transcode("0 0 10 10"));//0 0 10 10  //0 0 100 100
	styleHelper.WriteAttribute(line_marker_node2, "refX", XMLString::transcode("8"));//10  //50
	styleHelper.WriteAttribute(line_marker_node2, "refY", XMLString::transcode("5"));//5 //50
	styleHelper.WriteAttribute(line_marker_node2, "markerWidth", XMLString::transcode("10"));//10  //10
	styleHelper.WriteAttribute(line_marker_node2, "markerUnits", XMLString::transcode("strokeWidth"));
	styleHelper.WriteAttribute(line_marker_node2, "markerHeight", XMLString::transcode("10"));//10 //10
	styleHelper.WriteAttribute(line_marker_node2, "orient", XMLString::transcode("auto"));

	DOMElement *arrow_path_node2 = svg->getOwnerDocument()->createElement(XMLString::transcode("path"));

	styleHelper.WriteAttribute(arrow_path_node2, "d", XMLString::transcode("M 10,0 L 10,10 5,5 z"));//M 10,0 L 10,10 5,5 Z  //M 100,0 L 100,100 50,50 Z
	//styleHelper.WriteAttribute(arrow_path_node2, "fill", XMLString::transcode("black"));
	if((helper->GetAttributeValue(vml_attr_map, "strokecolor") != NULL) && XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "stroked"), XMLString::transcode("f")) != 0)
	{
		styleHelper.WriteAttribute(arrow_path_node2, "fill", colorHelper.GetColor(helper->GetAttributeValue(vml_attr_map, "strokecolor")));
	}
	else
	{
		styleHelper.WriteAttribute(arrow_path_node2, "fill", XMLString::transcode("black"));
	}

	if((helper->GetAttributeValue(vml_attr_map, "from") != NULL) && (helper->GetAttributeValue(vml_attr_map, "to") != NULL) && (helper->GetAttributeValue(vml_attr_map, "id") != NULL))
	{
		line_node = svg->getOwnerDocument()->createElement(XMLString::transcode("line"));
		map<string, XMLCh*> styleMap;
		vector<string> coords;
		styleHelper.ParseStyle(helper->GetAttributeValue(vml_attr_map, "style"), &styleMap);

		string from = helper->convertToString(helper->GetAttributeValue(vml_attr_map, "from"));
		string to = helper->convertToString(helper->GetAttributeValue(vml_attr_map, "to"));


		helper->StrTokenize(from, ",", &coords);
		vector<string>::iterator fromiter = coords.begin();		
		styleHelper.WriteAttribute(line_node, "x1", helper->convertToXMLCh(*fromiter));
		fromiter++;		
		styleHelper.WriteAttribute(line_node, "y1", helper->convertToXMLCh(*fromiter));

		coords.clear();

		helper->StrTokenize(to, ",", &coords);
		fromiter = coords.begin();
		styleHelper.WriteAttribute(line_node, "x2", helper->convertToXMLCh(*fromiter));
		fromiter++;		
		styleHelper.WriteAttribute(line_node, "y2", helper->convertToXMLCh(*fromiter));

		line_node = SetNodeAttributes(vml_attr_map, line_node, node);

		//styleHelper.WriteAttribute(svg, "stroke-width", helper->GetAttributeValue(vml_attr_map, "strokeweight"));

		styleHelper.WriteAttribute(svg, "style", helper->GetAttributeValue(vml_attr_map, "style"));
		styleHelper.WriteAttribute(svg, "xmlns", "http://www.w3.org/2000/svg");
		styleHelper.WriteAttribute(svg, "xmlns:xlink", "http://www.w3.org/1999/xlink");
		styleHelper.WriteAttribute(svg, "version", "1.1");
		styleHelper.WriteAttribute(svg, "preserveAspectRatio", "none");//xMinYMin meet 

	}

	line_marker_node->appendChild(arrow_path_node);
	line_marker_node2->appendChild(arrow_path_node2);
	defs->appendChild(line_marker_node);
	defs2->appendChild(line_marker_node2);
	svg->appendChild(defs);
	svg->appendChild(defs2);

	if(line_node != NULL)
	{
		svg->appendChild(line_node);
	}

	return svg;
}

string VML2SVG::GetViewbox(DOMNamedNodeMap *attr_map)
{
	XMLHelper *helper = XMLHelper::getInstance();

	//Set the viewbox on the SVG node
	if(helper->GetAttributeValue(attr_map, "coordorigin") != NULL)
	{
		string viewBox = XMLString::transcode(helper->GetAttributeValue(attr_map, "coordorigin"));
		int pos = 0;

		//if ,y or x, is present introduce a 0
		while(pos >= 0)
		{
			pos = viewBox.find(",");
			if(pos == 0)
			{
				viewBox.insert(pos, "0");
			}

			else if(pos == (int)viewBox.length())
			{
				viewBox.insert(pos, "0");
			}
			pos = -1;
		}
		pos = viewBox.find(",");

		if(pos == string::npos)
		{
			viewBox.insert((int)viewBox.length(), ",0");
		}
		if(helper->GetAttributeValue(attr_map, "coordsize") != NULL)
		{			
			viewBox.append(",").append(helper->convertToString(helper->GetAttributeValue(attr_map, "coordsize")));
			return viewBox;
		}
		else
		{
			viewBox.append(",0,0");
			return viewBox;
		}
	}
	else
	{
		if(helper->GetAttributeValue(attr_map, "coordsize") != NULL)
		{
			string viewBox = "0,0,";
			return viewBox.append(",").append(helper->convertToString(helper->GetAttributeValue(attr_map, "coordsize")));			
		}
	}
}

XMLCh* VML2SVG::InterpretPath(XMLCh* path, DOMNamedNodeMap *shapetype_attr_map, DOMNamedNodeMap *shape_attr_map,
							  map<string, FormulaContainer> formulae )
{
	string vml_path = XMLString::transcode(path);
	string svg_path;
	XMLHelper *helper = XMLHelper::getInstance();
	int pos = 0;

	//replace ,, with ,0,
	while(pos >= 0)
	{
		pos = vml_path.find(",,");
		if(pos > 0)
		{
			vml_path.insert(pos+1, "0");
		}
	}

	//if ,l or ,m or l, or m, or other verb is present, introduce a 0
	pos = 0;
	while (pos != string::npos)
	{
		pos = vml_path.find(",", pos + 1);
		int npos = pos + 1;
		if(pos > 0 && (vml_path[npos] == 'm' || vml_path[npos] == 'l' || vml_path[npos] == 'c' || (vml_path[npos] == 'x' && vml_path[npos + 1] == 'e')
			|| vml_path[npos] == 't' || vml_path[npos] == 'r' || vml_path[npos] == 'v'
			|| vml_path[npos] == 'n' || vml_path[npos] == 'a' || vml_path[npos] == 'w' || vml_path[npos] == 'q'))
		{
			vml_path.insert(npos, "0, ");
		}
		int apos = pos - 1;
		if(pos > 0 && (vml_path[apos] == 'm' || vml_path[apos] == 'l' || vml_path[apos] == 'c' || (vml_path[apos] == 'x' && vml_path[apos + 1] == 'e')
			|| vml_path[apos] == 't' || vml_path[apos] == 'r' || vml_path[apos] == 'v'
			|| vml_path[apos] == 'n' || vml_path[apos] == 'a' || vml_path[apos] == 'w' || vml_path[apos] == 'q'))
		{
			vml_path.insert(pos, " 0");
		}
	}

	// introducing a , before  @x x->equation number (int)
	pos = 0;
	while (pos != string::npos)
	{
		pos = vml_path.find_first_of("@", pos + 1);

		int apos = pos - 1;
		if(pos > 1 && (vml_path[apos] != ',') && ( vml_path[apos] != 'l') )
		{
			if( vml_path[apos] == 'l')
			{
				vml_path.insert(pos, " ");
			}
			else
			{
				vml_path.insert(pos, ",");
			}
		}
	}
	// introducing a ,  after @x x->equation number (int)
	pos = 0;
	while (pos != string::npos)
	{
		pos = vml_path.find_first_of("@", pos + 3);
		int npos = pos + 2;

		if(pos > 1 && (vml_path[npos] != ','))
		{
			vml_path.insert(npos, ", ");
		}
	}
	//Include ,l or ,m where there is no comma
	PreparePathVerbs(vml_path, 'm');
	PreparePathVerbs(vml_path, 'l');
	PreparePathVerbs(vml_path, 'c');
	PreparePathVerbs(vml_path, 'x');
	//PreparePathVerbs(vml_path, 'e');
	PreparePathVerbs(vml_path, 't');
	PreparePathVerbs(vml_path, 'r');
	PreparePathVerbs(vml_path, 'v');
	PreparePathVerbs(vml_path, 'n');
	PreparePathVerbs(vml_path, 'a');
	PreparePathVerbs(vml_path, 'w');
	PreparePathVerbs(vml_path, 'q');

	// formulas handled
	FormulaContainer handleFormula;
	vml_path = handleFormula.GetFormulaValue(vml_path, formulae);

	//Convert to SVG verbs
	vector<string> path_tokens;	
	helper->StrTokenize(vml_path,",", &path_tokens);
	vector<string>::iterator path_iter = path_tokens.begin();

	string s_temp;
	string previousVerb = "";
	string currVerb = "";

	while(path_iter != path_tokens.end())
	{
		s_temp = InsertSVGPathVerb(*path_iter, currVerb);
		if(currVerb.length() == 0)
		{
			s_temp.insert(0, previousVerb);
			currVerb.erase();
		}
		else
		{
			if(currVerb == "z ")
			{
				svg_path.append(s_temp);
				break;
			}
			previousVerb = currVerb;
			currVerb.erase();
		}	

		svg_path.append(s_temp).append(",");
		path_iter++;

		if(path_iter != path_tokens.end())
		{
			s_temp = *path_iter;
			svg_path.append(s_temp).append(" ");
			path_iter++;
		}
	}
	return helper->convertToXMLCh(svg_path);
}

void VML2SVG::PreparePathVerbs(string& token, char key)
{
	int pos = 1;

	while (pos != string::npos)
	{
		pos = token.find(key, pos + 1);
		int npos = pos - 1;
		if(pos != string::npos && ((token[pos - 1] != ',') && (token[pos - 1] != ' ' && token[pos - 2] != ',')))
		{
			token.insert(pos, ",");
		}
	}	
}

string VML2SVG::InsertSVGPathVerb(string token, string &prevVerb)
{
	int pos = 0;

	pos = token.find("m");
	if(pos != string::npos)
	{
		token.replace(pos, 1, "M ");
		prevVerb = "M ";
	}

	pos = 0;
	pos = token.find("l");
	if(pos != string::npos)
	{
		token.replace(pos, 1, "L ");
		prevVerb = "L ";
	}

	pos = 0;
	pos = token.find("r");
	if(pos != string::npos)
	{
		token.replace(pos, 1, "l ");
		prevVerb = "l ";
	}

	pos = 0;
	pos = token.find("xe");
	if(pos != string::npos)
	{
		token.replace(pos, 3, "z ");
		prevVerb = "z ";
	}

	return token;
}

void  VML2SVG::InitializeShapeTypeNode(DOMElement* node, DOMElement *svg, DOMElement* shape_node, DOMNamedNodeMap *shapetype_attr_map )
{
	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;

	DOMNamedNodeMap *shape_attr_map = shape_node->getAttributes();
	DOMElement *parent_svg = svg->getOwnerDocument()->createElement(XMLString::transcode("svg"));

	parent_svg = SetParentSvgNodeAttr(parent_svg, shape_node, shapetype_attr_map);

	DOMElement *path_node = svg->getOwnerDocument()->createElement(XMLString::transcode("path"));
	DOMElement *g_node = svg->getOwnerDocument()->createElement(XMLString::transcode("g"));

	//Set viewbox on parent svg node.
	string viewbox = GetViewbox(shapetype_attr_map);

	styleHelper.WriteAttribute(parent_svg, "viewBox", helper->convertToXMLCh(viewbox));

	XMLCh *adj = NULL;
	if(helper->GetAttributeValue(shape_attr_map, "adj") != NULL)
	{
		adj = helper->GetAttributeValue(shape_attr_map, "adj");
	}
	else
	{
		adj = helper->GetAttributeValue(shapetype_attr_map, "adj");
	}

	vector<string> adjust;

	if(adj != NULL)
	{
		string s_adj = XMLString::transcode(adj);

		int pos = 0;
		//if ,y or x, is present introduce a 0
		while(pos >= 0)
		{
			pos = s_adj.find(",");
			if(pos == 0)
			{
				s_adj.insert(pos, "0");
			}

			else if(pos == (int)s_adj.length())
			{
				s_adj.insert(pos, "0");
			}
			pos = -1;
		}
		pos = 0;
		//replace ,, with ,0,
		while(pos >= 0)
		{
			pos = s_adj.find(",,");
			if(pos > 0)
			{
				s_adj.insert(pos+1, "0");
			}
		}
		helper->StrTokenize(s_adj,",", &adjust);
	}
	//Get the formula list
	map<string, FormulaContainer> formulae;
	DOMNodeList *childlist = node->getElementsByTagName(XMLString::transcode("v:formulas"));	

	XMLSize_t child_list_size = childlist->getLength();

	DOMElement* formula = dynamic_cast<DOMElement*>(childlist->item(0));

	for(int i = 0;i< child_list_size ; i++)
	{
		if (XMLString::compareString(formula->getNodeName(), XMLString::transcode("v:formulas")) == 0)
		{
			ReadFormulaeNode(dynamic_cast<DOMElement*>(childlist->item(0)), &formulae, adjust, shapetype_attr_map);
		}	
	}

	XMLCh *svg_path = NULL;
	if (helper->GetAttributeValue(shapetype_attr_map, "path") != NULL)
	{
		svg_path = InterpretPath(helper->GetAttributeValue(shapetype_attr_map, "path"), shapetype_attr_map, shape_attr_map, formulae);		
	}

	//Check whether the shape is a Line.
	XMLCh *line = NULL;
	if((helper->GetAttributeValue(shapetype_attr_map, "o:spt")) != NULL)
	{
		line = helper->GetAttributeValue(shapetype_attr_map, "o:spt");
	}

	XMLCh *option_line = XMLString::transcode("32");
	XMLCh *option_line1 = XMLString::transcode("34");
	XMLCh *option_line2 = XMLString::transcode("38");

	if((XMLString::compareString(line, option_line) == 0) || (XMLString::compareString(line, option_line1) == 0)
		|| (XMLString::compareString(line, option_line2) == 0))
	{ 
		g_node = InitializeLineNode(node, g_node, shape_attr_map);
		string token = helper->convertToString(svg_path);

		if(((int)token.length() - 2) == (int)token.find_last_of("e"))
		{
			token.erase(((int)token.length() - 2), 2);
		}
		svg_path = helper->convertToXMLCh(token);
	}

	//Process the shape type attributes
	styleHelper.WriteAttribute(path_node, "d", svg_path);	

	path_node = SetNodeAttributes(shape_attr_map, path_node, node);

	text_parent_node = parent_svg;

	if(shape_node->hasChildNodes())
	{
		if(XMLString::compareString((shape_node->getFirstChild())->getNodeName(), XMLString::transcode("v:fill")) == 0)
		{
			DOMElement *img_node = svg->getOwnerDocument()->createElement(XMLString::transcode("image"));
			img_node = HandleImageFill(path_node, dynamic_cast<DOMElement*>(shape_node->getFirstChild()), svg, shape_attr_map); 
			if(img_node != NULL)
			{
				parent_svg->appendChild(img_node);

				string url = "url(#";
				url.append(helper->convertToString(helper->GetAttributeValue(shape_attr_map, "id"))).append(")");
				path_node->setAttribute(XMLString::transcode("fill"), helper->convertToXMLCh(url));
			}
		}
		ProcessVMLNode(dynamic_cast<DOMElement*>(shape_node->getFirstChild()), path_node);
	}

	if(node->hasChildNodes())
	{ 
		ProcessVMLNode(dynamic_cast<DOMElement*>(node->getFirstChild()), path_node);
	}

	g_node->appendChild(path_node);

	if (helper->convertToString(text_parent_node->getNodeName()) == "text")
	{
		SetTextboxParentNode(svg, parent_svg, text_parent_node, path_node, shape_attr_map);
		return;
	}

	parent_svg->appendChild(g_node);
	svg->appendChild(parent_svg);

	XMLString::release((XMLCh**)&option_line);
	XMLString::release((XMLCh**)&option_line1);
	XMLString::release((XMLCh**)&option_line2);
}

DOMElement*  VML2SVG::HandleStrokeNode(DOMNamedNodeMap *node_attr_map, DOMElement *vml, DOMElement *svg)
{
	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;
	ColorHelper colorHelper;

	DOMNamedNodeMap *parent_attr_map = (vml->getParentNode())->getAttributes();

	XMLCh * flag_x = helper->GetAttributeValue(node_attr_map, "on");
	if(flag_x != NULL)
	{
		if((XMLString::compareString(flag_x, XMLString::transcode("false"))) || (XMLString::compareString(flag_x, XMLString::transcode("0"))))
		{
			return svg;
		}
	}

	XMLCh *svg_col = helper->GetAttributeValue(svg, "stroked");
	XMLCh *flag = XMLString::transcode("f");

	//check for stroke is flaged here or in its parent node
	if((XMLString::compareString(helper->GetAttributeValue(node_attr_map, "stroked"), flag) != 0) && 
		(XMLString::compareString(helper->GetAttributeValue(parent_attr_map, "stroked"), flag) != 0))
	{
		if((helper->GetAttributeValue(node_attr_map, "strokecolor") != NULL) ||
			(XMLString::compareString(helper->GetAttributeValue(svg, "stroke"), XMLString::transcode("")) != 0))
		{
			if((helper->GetAttributeValue(node_attr_map, "strokecolor") != NULL) && 
				(XMLString::compareString(helper->GetAttributeValue(node_attr_map, "stroked"), flag) != 0))
			{
				svg->setAttribute(XMLString::transcode("stroke"), colorHelper.GetColor(helper->GetAttributeValue(node_attr_map, "strokecolor")));
			}
			else
			{
				svg->setAttribute(XMLString::transcode("stroke"), helper->GetAttributeValue(svg, "stroke"));
			}		
		}
		else 
		{
			svg->setAttribute(XMLString::transcode("stroke"), XMLString::transcode("black"));
		}

		if((helper->GetAttributeValue(node_attr_map, "strokeweight") != NULL) && (XMLString::compareString(helper->GetAttributeValue(node_attr_map, "stroked"), flag) != 0))
		{
			styleHelper.WriteAttribute(svg, "stroke-width", helper->GetAttributeValue(node_attr_map, "strokeweight")); 
		}

		styleHelper.WriteAttribute(svg, "stroke-opacity", helper->GetAttributeValue(node_attr_map, "opacity")); 
		styleHelper.WriteAttribute(svg, "stroke-miterlimit", helper->GetAttributeValue(node_attr_map, "miterlimit")); 
		styleHelper.WriteAttribute(svg, "stroke-linejoin", helper->GetAttributeValue(node_attr_map, "joinstyle")); 
		styleHelper.WriteAttribute(svg, "stroke-linecap", helper->GetAttributeValue(node_attr_map, "endcap")); 

		if(XMLString::compareString((vml->getParentNode())->getNodeName(), XMLString::transcode("v:shape")) == 0)
		{					
			if(GetStrokeDashValue(node_attr_map, vml) != NULL)
			{
				float weight = 1;
				if(helper->GetAttributeValue(svg, "stroke-width") != NULL)
				{
					weight = helper->convertToFloat(helper->GetAttributeValue(svg, "stroke-width"));
				}
				vector<string> dash_tokens;	
				helper->StrTokenize(helper->convertToString(GetStrokeDashValue(node_attr_map, vml)),",", &dash_tokens);
				vector<string>::iterator dash_iter = dash_tokens.begin();

				string s_dash;
				string s_dashvalue;

				for(int i = 0; dash_tokens.size() > i; i++)
				{					
					s_dashvalue = *dash_iter;
					s_dash.append(helper->convertToString(helper->convertToFloat(s_dashvalue) * weight));

					if(dash_tokens.size() == (i + 1))
					{
						s_dash.append(" ");
					}
					else
					{
						s_dash.append(",");
					}

					dash_iter++;
					s_dashvalue.erase();
				}
				styleHelper.WriteAttribute(svg, "stroke-dasharray", helper->convertToXMLCh(s_dash));
			}
		}
		else
		{
			styleHelper.WriteAttribute(svg, "stroke-dasharray", GetStrokeDashValue(node_attr_map, vml));
		}
	}

	if(helper->GetAttributeValue(node_attr_map, "startarrow") != NULL)
	{
		string id = "url(#ArrowStart";
		if(helper->GetAttributeValue(svg, "id") != NULL)	
		{
			id.append(helper->convertToString(helper->GetAttributeValue(svg, "id"))).append(")");
		}
		else
		{
			id.append("0");
		}
		styleHelper.WriteAttribute(svg, "xmlns:xlink", "http://www.w3.org/1999/xlink");
		styleHelper.WriteAttribute(svg, "marker-start", helper->convertToXMLCh(id)); 
	}

	if(helper->GetAttributeValue(node_attr_map, "endarrow") != NULL)
	{
		string id = "url(#ArrowEnd";
		if(helper->GetAttributeValue(svg, "id") != NULL)	
		{
			id.append(helper->convertToString(helper->GetAttributeValue(svg, "id"))).append(")");
		}
		else
		{
			id.append("0");
		}
		styleHelper.WriteAttribute(svg, "xmlns:xlink", "http://www.w3.org/1999/xlink");
		styleHelper.WriteAttribute(svg, "marker-end", helper->convertToXMLCh(id)); 
	}

	XMLString::release((XMLCh**)&flag);

	return svg;
}

XMLCh* VML2SVG::GetStrokeDashValue(DOMNamedNodeMap *attr_map, DOMElement* vml)
{
	DOMAttr *node_attr = NULL;

	for(XMLSize_t j = 0; j < attr_map->getLength(); j++)
	{
		node_attr = dynamic_cast<DOMAttr*>(attr_map->item(j));
		const XMLCh *node_attr_name = node_attr->getName();

		if(XMLString::compareString( node_attr_name, XMLString::transcode("dashstyle") ) == 0)
		{
			return GetDashStyleValue(node_attr->getValue());
		}
		if(XMLString::compareString(node_attr_name, XMLString::transcode("linestyle")) == 0)
		{
			return GetDashStyleValue(node_attr->getValue());
		}
	}
	return NULL;
}

XMLCh* VML2SVG::GetDashStyleValue(const XMLCh* dashstyle)
{
	PopulateDashStyle();
	XMLHelper *helper = XMLHelper::getInstance();
	map<XMLCh*,XMLCh*>::iterator iter = dashStyleList.begin();	
	XMLCh *dashStylevalue = NULL;

	while (iter != dashStyleList.end())	
	{		
		if (XMLString::compareString(dashstyle, iter->first) == 0)
		{
			dashStylevalue = iter->second;
			break;
		}
		iter++;
	}

	if(dashStylevalue != NULL)
	{
		return dashStylevalue;
	}

	string s_dashvalue = helper->convertToString(dashstyle);
	int pos = 0;
	while  (pos != string::npos)
	{
		pos = s_dashvalue.find(" ");
		if(pos >= 0)
		{
			s_dashvalue.replace(pos, 1, ",");
		}
	}
	//XMLString::release((XMLCh**)&dashStylevalue);
	return helper->convertToXMLCh(s_dashvalue);
}

DOMElement*  VML2SVG::SetParentSvgNodeAttr(DOMElement *parent_svg, DOMElement *vml){

	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;

	DOMNamedNodeMap *attr_map = vml->getAttributes();

	styleHelper.WriteAttribute(parent_svg, "xmlns", "http://www.w3.org/2000/svg");
	styleHelper.WriteAttribute(parent_svg, "xmlns:xlink", "http://www.w3.org/1999/xlink");
	styleHelper.WriteAttribute(parent_svg, "version", "1.1");
	styleHelper.WriteAttribute(parent_svg, "preserveAspectRatio", "none");//xMinYMin meet 


	map<string, XMLCh*> styleMap;
	if(helper->GetAttributeValue(attr_map, "style") != NULL)
	{
		styleHelper.ParseStyle(helper->GetAttributeValue(attr_map, "style"), &styleMap);

		//if(helper->GetAttributeValue(attr_map, "coordsize") == NULL){

		if(XMLString::compareString(vml->getNodeName(), XMLString::transcode("v:oval")) != 0)
		{
			styleHelper.WriteAttribute(parent_svg, "style",helper->GetAttributeValue(attr_map, "style"));
			if(styleHelper.GetWidthfromStyle(&styleMap) != NULL)
			{
				styleHelper.WriteAttribute(parent_svg, "width", styleHelper.GetWidthfromStyle(&styleMap));
			}

			if(styleHelper.GetHeightfromStyle(&styleMap) != NULL)
			{	
				styleHelper.WriteAttribute(parent_svg, "height", styleHelper.GetHeightfromStyle(&styleMap));
			}

			if(styleHelper.GetXcoordinatefromStyle(&styleMap) != NULL)
			{
				styleHelper.WriteAttribute(parent_svg, "x", styleHelper.GetXcoordinatefromStyle(&styleMap));
			}

			if(styleHelper.GetYcoordinatefromStyle(&styleMap) != NULL)
			{	
				styleHelper.WriteAttribute(parent_svg, "y", styleHelper.GetYcoordinatefromStyle(&styleMap));
			}	
		}
		else
		{
			string s_style = "position:absolute;z-index:";

			if(styleHelper.GetZAttrfromStyle(&styleMap) != NULL)
			{
				s_style.append(helper->convertToString(styleHelper.GetZAttrfromStyle(&styleMap)));
			}	
			styleHelper.WriteAttribute(parent_svg, "style",helper->convertToXMLCh(s_style));

			XMLCh *x_ry = styleHelper.GetRYfromStyle(&styleMap);								
			XMLCh *x_cy = styleHelper.GetCYfromStyle(&styleMap, (helper->convertToFloat(x_ry)));
			string units = styleHelper.GetUnits(x_ry);

			styleHelper.WriteAttribute(parent_svg, "height", helper->convertToXMLCh((helper->convertToString((helper->convertToFloat(x_cy)) + (helper->convertToFloat(x_ry)) * 2)).append(units)));								

			XMLCh *x_X = XMLString::transcode("0");
			if(styleHelper.GetXcoordinatefromStyle(&styleMap) != NULL)
			{
				x_X = styleHelper.GetXcoordinatefromStyle(&styleMap);
			}

			XMLCh *x_height = styleHelper.GetWidthfromStyle(&styleMap);
			units = styleHelper.GetUnits(x_height);
			styleHelper.WriteAttribute(parent_svg, "width", helper->convertToXMLCh((helper->convertToString((helper->convertToFloat(x_X)) + (helper->convertToFloat(x_height)))).append(units)));								

			XMLString::release((XMLCh**)&x_ry);
			XMLString::release((XMLCh**)&x_cy);
			XMLString::release((XMLCh**)&x_X);
			XMLString::release((XMLCh**)&x_height);
		}		
	}
	return parent_svg;
}

DOMElement*  VML2SVG::SetParentSvgNodeAttr(DOMElement *parent_svg, DOMElement *shape_node, 
										   DOMNamedNodeMap *shapetype_attr_map)
{
	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;

	DOMNamedNodeMap *shape_attr_map = shape_node->getAttributes();

	styleHelper.WriteAttribute(parent_svg, "xmlns", "http://www.w3.org/2000/svg");
	styleHelper.WriteAttribute(parent_svg, "version", "1.1");
	styleHelper.WriteAttribute(parent_svg, "preserveAspectRatio", "none");///xMinYMin meet


	map<string, XMLCh*> styleMap;
	string s_style = helper->convertToString(helper->GetAttributeValue(shape_attr_map, "style"));
	float f_height = 0.0;
	float f_width = 0.0;

	if(helper->GetAttributeValue(shape_attr_map, "style") != NULL)
	{
		styleHelper.ParseStyle(helper->GetAttributeValue(shape_attr_map, "style"), &styleMap);
		if(styleHelper.GetWidthfromStyle(&styleMap) != NULL)
		{
			styleHelper.WriteAttribute(parent_svg, "width", styleHelper.GetWidthfromStyle(&styleMap));
		}

		if(styleHelper.GetHeightfromStyle(&styleMap) != NULL)
		{	
			styleHelper.WriteAttribute(parent_svg, "height", styleHelper.GetHeightfromStyle(&styleMap));
		}

		if(styleHelper.GetXcoordinatefromStyle(&styleMap) != NULL)
		{
			styleHelper.WriteAttribute(parent_svg, "x", styleHelper.GetXcoordinatefromStyle(&styleMap));
		}

		if(styleHelper.GetYcoordinatefromStyle(&styleMap) != NULL)
		{	
			styleHelper.WriteAttribute(parent_svg, "y", styleHelper.GetYcoordinatefromStyle(&styleMap));
		}

		if(styleHelper.GetHeightfromStyle(&styleMap) != NULL)
		{
			f_height = helper->convertToFloat(styleHelper.GetHeightfromStyle(&styleMap));
		}

		//changing the height to 0.75 if it is less.
		if(f_height < 0.75)
		{
			f_height = 0.75;

			int pos_height = -1;
			pos_height = (int)s_style.find("height:");
			int colon = (int)s_style.find_first_of(";", pos_height);
			s_style.replace((pos_height + 6), (colon - (pos_height + 6)), ":0.75pt");
		}

		if(styleHelper.GetWidthfromStyle(&styleMap) != NULL)
		{
			f_width = helper->convertToFloat(styleHelper.GetWidthfromStyle(&styleMap));
		}

		//changing the width to 0.75 if it is less.
		if(f_width < 0.75)
		{
			f_width = 0.75;

			int pos_width = -1;
			pos_width = (int)s_style.find("width:");
			int colon = (int)s_style.find_first_of(";", pos_width);
			s_style.replace((pos_width + 5), (colon - (pos_width + 5)), ":0.75pt");
		}
	}

	if(helper->GetAttributeValue(shapetype_attr_map, "coordsize") != NULL)
	{
		styleHelper.WriteAttribute(parent_svg, "style", helper->convertToXMLCh(s_style));
	}
	return parent_svg;
}
/* 
This method is used to add the attributes to the svg node
*/
DOMElement* VML2SVG::SetNodeAttributes(DOMNamedNodeMap *vml_attr_map, DOMElement* svg_node, DOMElement* vml_node)
{
	const XMLCh *nodeName = vml_node->getNodeName();
	const XMLCh *parent_nodeName = vml_node->getParentNode()->getNodeName();

	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;
	ColorHelper colorHelper;
	float height = 0;
	float width = 0;
	float coord_x = 0; 
	float coord_y = 0;

	XMLCh *flag = XMLString::transcode("f"); 

	map<string, XMLCh*> styleMap;
	if(helper->GetAttributeValue(vml_attr_map, "style") != NULL)
	{
		styleHelper.ParseStyle(helper->GetAttributeValue(vml_attr_map, "style"), &styleMap);
	}
	if((helper->GetAttributeValue(vml_attr_map, "id")) != NULL)
	{
		styleHelper.WriteAttribute(svg_node, "id", helper->GetAttributeValue(vml_attr_map, "id"));
	}

	if(styleHelper.GetWidthfromStyle(&styleMap) != NULL)
	{
		styleHelper.WriteAttribute(svg_node, "width", styleHelper.GetWidthfromStyle(&styleMap));
	}

	if(styleHelper.GetHeightfromStyle(&styleMap) != NULL)
	{	
		styleHelper.WriteAttribute(svg_node, "height", styleHelper.GetHeightfromStyle(&styleMap));
	}

	if(XMLString::compareString(nodeName, XMLString::transcode("v:oval")) != 0)
	{
		if(helper->convertToFloat(styleHelper.GetRotationAttrFromStyle(&styleMap)) != 0.0)
		{
			if (XMLString::compareString(nodeName, XMLString::transcode("v:shapetype")) == 0) 
			{
				coord_x = 21600;
				coord_y = 21600;
			}

			if (XMLString::compareString(nodeName, XMLString::transcode("v:rect")) == 0) 
			{
				coord_x = helper->convertToFloat(styleHelper.GetXcoordinatefromStyle(&styleMap)) * 1.33;
				coord_y = helper->convertToFloat(styleHelper.GetYcoordinatefromStyle(&styleMap)) * 1.33;
			}

			if(styleHelper.GetRotateTransformFromStyle(svg_node, helper->convertToFloat(styleHelper.GetRotationAttrFromStyle(&styleMap)), coord_x, coord_y) != NULL)
			{

				styleHelper.WriteAttribute(svg_node, "transform", styleHelper.GetRotateTransformFromStyle(svg_node,
				helper->convertToFloat(styleHelper.GetRotationAttrFromStyle(&styleMap)), coord_x, coord_y));
			}
		}
	}

	if(styleHelper.GetFlipAttrValueForSVG(helper->convertToString(styleHelper.GetFlipAttrFromStyle(&styleMap, svg_node))) != NULL)
	{
		styleHelper.WriteAttribute(svg_node, "transform", styleHelper.GetFlipAttrValueForSVG(helper->convertToString(styleHelper.GetFlipAttrFromStyle(&styleMap, svg_node))));
	}

	if(XMLString::compareString(nodeName, XMLString::transcode("v:oval")) == 0)	
	{
		float f_rx = helper->convertToFloat(styleHelper.GetRXfromStyle(&styleMap));
		if(styleHelper.GetRXfromStyle(&styleMap) != NULL)
		{
			styleHelper.WriteAttribute(svg_node, "rx", styleHelper.GetRXfromStyle(&styleMap));
		}

		float f_ry = helper->convertToFloat(styleHelper.GetRYfromStyle(&styleMap));
		if(styleHelper.GetRYfromStyle(&styleMap) != NULL)
		{
			styleHelper.WriteAttribute(svg_node, "ry", styleHelper.GetRYfromStyle(&styleMap));
		}

		if(styleHelper.GetCXfromStyle(&styleMap, f_rx) != NULL)
		{
			styleHelper.WriteAttribute(svg_node, "cx", styleHelper.GetCXfromStyle(&styleMap, f_rx));
		}
		if(styleHelper.GetCYfromStyle(&styleMap, f_ry) != NULL)
		{
			styleHelper.WriteAttribute(svg_node, "cy", styleHelper.GetCYfromStyle(&styleMap, f_ry));
		}

		if(helper->convertToFloat(styleHelper.GetRotationAttrFromStyle(&styleMap)) != 0.0)
		{
			if(styleHelper.GetRotateTransformFromStyle(svg_node, helper->convertToFloat(styleHelper.GetRotationAttrFromStyle(&styleMap)), coord_x, coord_y) != NULL)
			{
				coord_x = helper->convertToFloat(styleHelper.GetCXfromStyle(&styleMap, f_rx));
				coord_y = helper->convertToFloat(styleHelper.GetCYfromStyle(&styleMap, f_ry));

				styleHelper.WriteAttribute(svg_node, "transform", styleHelper.GetRotateTransformFromStyle(svg_node,
				helper->convertToFloat(styleHelper.GetRotationAttrFromStyle(&styleMap)), coord_x, coord_y));
			}
		}
	}
	if((helper->GetAttributeValue(vml_attr_map, "fillcolor") != NULL) && XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "filled"), flag) != 0)
	{
		styleHelper.WriteAttribute(svg_node, "fill", colorHelper.GetColor(helper->GetAttributeValue(vml_attr_map, "fillcolor")));
	}
	else
	{
		styleHelper.WriteAttribute(svg_node, "fill", XMLString::transcode("white"));
	}

	//check for stroke is flaged and its previous value 
	if((helper->GetAttributeValue(vml_attr_map, "strokecolor") != NULL) || (XMLString::compareString(helper->GetAttributeValue(svg_node, "stroke"),XMLString::transcode("")) != 0))
	{	
		if((helper->GetAttributeValue(vml_attr_map, "strokecolor") != NULL) && (XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "stroked"), flag) != 0))
		{
			svg_node->setAttribute(XMLString::transcode("stroke"), colorHelper.GetColor(helper->GetAttributeValue(vml_attr_map, "strokecolor")));
		}
		else 
		{	
			svg_node->setAttribute(XMLString::transcode("stroke"), XMLString::transcode("black"));
		}		
	}
	else
	{	
		svg_node->setAttribute(XMLString::transcode("stroke"), XMLString::transcode("black"));
	}

	//generate suitable value for stroke-width	
	if((helper->GetAttributeValue(vml_attr_map, "type") != NULL) && 
		((XMLString::compareString(nodeName, XMLString::transcode("v:shapetype")) == 0)) ||((XMLString::compareString(parent_nodeName, XMLString::transcode("v:group")) == 0)))		
	{
		if(XMLString::compareString(nodeName, XMLString::transcode("v:line")) == 0)
		{
			map<string, XMLCh*> parent_styleMap;

			if(helper->GetAttributeValue(dynamic_cast<DOMElement*>(vml_node->getParentNode()), "style") != NULL)
			{
				styleHelper.ParseStyle(helper->GetAttributeValue(dynamic_cast<DOMElement*>(vml_node->getParentNode()), "style"), &parent_styleMap);
				
				if(styleHelper.GetWidthfromStyle(&parent_styleMap) != NULL)
				{
					width = helper->convertToFloat(styleHelper.GetWidthfromStyle(&parent_styleMap));
				}

				if(styleHelper.GetHeightfromStyle(&parent_styleMap) != NULL)
				{		
					height = helper->convertToFloat(styleHelper.GetHeightfromStyle(&parent_styleMap));
				}

				vector<string> coordtokens;
				string s_coord = helper->convertToString(helper->GetAttributeValue(dynamic_cast<DOMElement*>(vml_node->getParentNode()), "coordsize"));
				helper->StrTokenize(s_coord , ",", &coordtokens);

				vector<string>::iterator coorditer = coordtokens.begin();
				float coord_width, coord_height;

				coord_width = helper->convertToFloat(*coorditer);

				coorditer++;
				coord_height = helper->convertToFloat(*coorditer);

				float f_weight = ((coord_width / width ) + (coord_height / height)) / 2;

				styleHelper.WriteAttribute(svg_node, "stroke-width", helper->convertToXMLCh(helper->convertToString(f_weight * 10).append("pt"))); 				
			}
		}
		else
		{		
			if(styleHelper.GetWidthfromStyle(&styleMap) != NULL)
			{
				width = helper->convertToFloat(styleHelper.GetWidthfromStyle(&styleMap));
			}
			else if(width == 0)
			{
				width = 0.75;
			}

			if(styleHelper.GetHeightfromStyle(&styleMap) != NULL)
			{		
				height = helper->convertToFloat(styleHelper.GetHeightfromStyle(&styleMap));
			}
			else if(height == 0)
			{
				height = 0.75;
			}

			float f_weight = ((21600 / width ) + (21600 / height)) / 2;
			if((helper->GetAttributeValue(vml_attr_map, "strokeweight") == NULL) && XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "stroked"), flag) != 0)
			{
				styleHelper.WriteAttribute(svg_node, "stroke-width", helper->convertToXMLCh(f_weight)); 
			}
			else if(XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "stroked"), flag) != 0)
			{
				f_weight = f_weight * helper->convertToFloat(helper->GetAttributeValue(vml_attr_map, "strokeweight"));	
				styleHelper.WriteAttribute(svg_node, "stroke-width", helper->convertToXMLCh(helper->convertToString(f_weight).append("pt"))); 
			}
		}
	}
	else if(XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "stroked"), flag) != 0)
	{
		if(helper->GetAttributeValue(vml_attr_map, "strokeweight") == NULL)
		{
			styleHelper.WriteAttribute(svg_node, "stroke-width", XMLString::transcode("1pt")); 
		}
		else
		{
			styleHelper.WriteAttribute(svg_node, "stroke-width", helper->GetAttributeValue(vml_attr_map, "strokeweight")); 
		}	
	}

	XMLString::release((XMLCh**)&flag);
	return svg_node;
}


void  VML2SVG::PopulateDashStyle()
{
	/* * ShortDash 2 2
	* ShortDot 02
	* ShortDashDot  2202
	* ShortDashDotDot  220202
	* Dot  1 2
	* Dash 4 2
	* LongDash 8 2
	* DashDot 4212
	* LongDashDot 8212
	* LongDashDotDot 821212*/

	dashStyleList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("shortDash"), XMLString::transcode("2,2")));
	dashStyleList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("shortDot"), XMLString::transcode("0,2")));
	dashStyleList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("shortDashDot"), XMLString::transcode("2,2,0,2")));
	dashStyleList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("shortDashDotDot"), XMLString::transcode("2,2,0,2,0,2")));
	dashStyleList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("dot"), XMLString::transcode("1,2")));
	dashStyleList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("dash"), XMLString::transcode("4,2")));//4,2
	dashStyleList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("longDash"), XMLString::transcode("8,2")));
	dashStyleList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("dashDot"), XMLString::transcode("4,2,1,2")));
	dashStyleList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("longDashDot"), XMLString::transcode("8,2,1,2")));
	dashStyleList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("longDashDotDot"), XMLString::transcode("8,2,1,2,1,2")));
}

/* -------------- Formula Container---------------- */
FormulaContainer::FormulaContainer()
{
}
FormulaContainer::FormulaContainer(string id, string v, string p1, string p2, int command)
{
	f_id = id;
	f_v = v;
	f_p1 = p1;
	f_p2 = p2;
	f_command = command;
}

string FormulaContainer::GetAdjustment(string formulanode, vector<string> adjustmentlist)
{
	string checkadj = formulanode.substr(0, 1);
	string returnval = formulanode;
	XMLHelper *helper = XMLHelper::getInstance();

	if(checkadj.compare("#") == 0)
	{	
		int adjNo = helper->convertToInt(formulanode.substr(1, formulanode.length() - 1));
		returnval = adjustmentlist[adjNo];
	}	

	return returnval;
}

FormulaContainer::FormulaContainer(string id, const char *formula, vector<string> adjlist, DOMNamedNodeMap* styleAttrList)
{	
	XMLHelper *helper =  XMLHelper::getInstance();
	StyleHelper styleHelper;
	vector<string> tokens;	 
	string formula_s = formula;
	f_id = id;
	int position = 0;

	//Deconstruct the formula
	helper->StrTokenize(formula_s, " ", &tokens);
	vector<string>::iterator iter = tokens.begin();

	//adjust height and width in formula
	/*map<string, XMLCh*> styleMap;

	styleHelper.ParseStyle(helper->GetAttributeValue(styleAttrList, "style"), &styleMap);
	string y_corr = adjlist.back();*/

	//XMLCh *height = helper->convertToXMLCh(helper->convertToFloat(styleHelper.GetHeightfromStyle(&styleMap, helper->convertToFloat(y_corr))));
	//adjlist.pop_back();
	// //helper->GetAttributeValue(styleAttrList, "height");
	//string x_corr = adjlist.back();
	//XMLCh *width = helper->convertToXMLCh(helper->convertToFloat(styleHelper.GetWidthfromStyle(&styleMap, helper->convertToFloat(x_corr))));

	XMLCh *coordsize = helper->GetAttributeValue(styleAttrList, "coordsize");
	string coord_y = "0";
	string coord_x= "0";

	if(coordsize != NULL)
	{
		vector<string> coordlist;

		helper->StrTokenize(helper->convertToString(coordsize), ",", &coordlist);
		vector<string>::iterator coorditer = coordlist.begin();

		coord_x = *coorditer;
		coorditer++;

		coord_y = *coorditer;
	}

	XMLCh *width = helper->convertToXMLCh(coord_x);
	XMLCh *height = helper->convertToXMLCh(coord_y);

	if(tokens.size() <= 0)
	{
		return;
	}

	//First parameter is the formula. Cannot be null
	string eqn = *iter;
	f_command = GetCommand(eqn);

	iter++;
	if(iter != tokens.end())
	{
		f_v = *iter;
		if(!adjlist.empty())
		{
			f_v = GetAdjustment(f_v, adjlist);
		}
		position = f_v.find_first_of("width");
		if(position > -1)			
		{
			f_v = helper->convertToString(width);
		}

		position = f_v.find_first_of("height");
		if(position > -1)
		{
			f_v = helper->convertToString(height);
		}

		iter++;
	}

	if(iter != tokens.end())
	{
		f_p1 = *iter; 
		f_p1 = GetAdjustment(f_p1, adjlist);

		position = f_v.find_first_of("width");
		if(position > -1)
		{
			f_p1 = helper->convertToString(width);
		}

		position = f_v.find_first_of("height");
		if(position > -1)
		{
			f_p1 = helper->convertToString(height);
		}
		iter++;
	}
	if(iter != tokens.end())
	{		
		f_p2 = *iter;		
		f_p2 = GetAdjustment(f_p2, adjlist);
		position = f_v.find_first_of("width");
		if(position > -1)
		{
			f_p2 = helper->convertToString(width);
		}
		position = f_v.find_first_of("height");
		if(position > -1)
		{
			f_p2 = helper->convertToString(height);
		}
	}
	XMLString::release((XMLCh**)&width);
	XMLString::release((XMLCh**)&height);
}

string FormulaContainer::GetFormulaValue(string value, map<string, FormulaContainer> formulaMap)
{
	XMLHelper *helper = XMLHelper::getInstance();
	int position = value.find_first_of("@");
	while(position != value.npos)
	{
		string key = value.substr(position,2);
		//Formula present.
		FormulaContainer *container = &(formulaMap[key]);

		if(container != NULL)
		{
			string container_value = container->ComputeFormula(formulaMap);
			/*float value_fl = helper->convertToFloat(container_value) * 1.33;
			value.replace(position,2,helper->convertToString(value_fl));*/
			value.replace(position,2,container_value);
		}
		position = value.find_first_of("@");
	}
	//value = (helper->convertToFloat(value)) * 1.33 ;
	return value;

}

string FormulaContainer::ComputeFormula(map<string, FormulaContainer> formulaMap)
{
	string returnvalue;
	XMLHelper *helper =  XMLHelper::getInstance();
	string t_v = GetFormulaValue(f_v, formulaMap);
	string t_p1 = GetFormulaValue(f_p1, formulaMap);
	string t_p2 = GetFormulaValue(f_p2, formulaMap);
	float res = 0;


	if(f_command == val)
	{
		returnvalue = t_v;
	}

	if(f_command ==  sum)
	{
		res = strtod(t_v.c_str(), NULL);

		if(!t_p1.empty())
		{
			res += strtod(t_p1.c_str(), NULL);			
		}
		if(!t_p2.empty())
		{
			res -= strtod(t_p2.c_str(), NULL);
		}

		returnvalue = helper->convertToString(res);
	}

	if(f_command == product)
	{
		res = strtod(t_v.c_str(), NULL);
		if(!t_p1.empty())
		{
			res *= strtod(t_p1.c_str(), NULL);			
		}
		if(!t_p2.empty() && strtod(t_p2.c_str(), NULL) != 0)
		{
			res /= strtod(t_p2.c_str(), NULL);
		}

		returnvalue = (int)res;

	}
	if(f_command == formulaCommand::mid)
	{
		res = strtod(t_v.c_str(), NULL);
		if(!t_p1.empty())
		{
			res = (res * strtod(t_p1.c_str(), NULL)) /2;
		}
		returnvalue = res;
	}
	if(f_command == formulaCommand::abs_)
	{	
		returnvalue = fabs(strtod(t_v.c_str(), NULL));
	}

	if(f_command == formulaCommand::min)
	{
		if(strtod(t_v.c_str(), NULL) <= strtod(t_p1.c_str(), NULL))
		{
			returnvalue = t_v;
		}
		else
		{
			returnvalue = t_p1; 
		}
	}
	if(f_command == formulaCommand::max)
	{
		if(strtod(t_v.c_str(), NULL) >= strtod(t_p1.c_str(), NULL))
		{
			returnvalue = t_v;
		}
		else
		{
			returnvalue = t_p1; 
		}
	}
	if(f_command == formulaCommand::if_)
	{
		if(strtod(t_v.c_str(), NULL) > 0)
		{
			returnvalue = t_p1;
		}
		else
		{
			returnvalue = t_p2;
		}

	}
	if(f_command == formulaCommand::mod)
	{
		double d_v = strtod(t_v.c_str(),NULL);
		double d_p1 = strtod(t_p1.c_str(),NULL);
		double d_p2 = strtod(t_p2.c_str(),NULL);

		res = sqrt(d_v*d_v + d_p1*d_p1 + d_p2*d_p2);
		returnvalue = res;
	}
	if(f_command == formulaCommand::atan2_)
	{
		double d_v = strtod(t_v.c_str(),NULL);
		double d_p1 = strtod(t_p1.c_str(),NULL);

		res = atan2(d_p1, d_v);
		returnvalue = res;
	}
	if(f_command == formulaCommand::sin_)
	{
		double d_v = strtod(t_v.c_str(),NULL);
		double d_p1 = strtod(t_p1.c_str(),NULL);

		res = d_v*d_v*sin(d_p1);

		returnvalue = res;		
	}
	if(f_command == formulaCommand::cos_)
	{
		double d_v = strtod(t_v.c_str(),NULL);
		double d_p1 = strtod(t_p1.c_str(),NULL);

		res = d_v*d_v*cos(d_p1);

		returnvalue = res;

	}
	if(f_command == formulaCommand::cosatan2)
	{
		double d_v = strtod(t_v.c_str(),NULL);
		double d_p1 = strtod(t_p1.c_str(),NULL);
		double d_p2 = strtod(t_p2.c_str(),NULL);

		res = d_v*d_v*cos(atan2(d_p2,d_p1));

		returnvalue = res;
	}
	if(f_command == formulaCommand::sinatan2)
	{
		double d_v = strtod(t_v.c_str(),NULL);
		double d_p1 = strtod(t_p1.c_str(),NULL);
		double d_p2 = strtod(t_p2.c_str(),NULL);

		res = d_v*d_v*sin(atan2(d_p2,d_p1));

		returnvalue = res;
	}
	if(f_command == formulaCommand::sqrt_)
	{
		res = sqrt(strtod(t_v.c_str(), NULL));
		returnvalue = res;
	}
	if(f_command == formulaCommand::sumangle)
	{
		//v + p1 * 2^16 + p2*2^16
		double d_v = strtod(t_v.c_str(),NULL);
		double d_p1 = strtod(t_p1.c_str(),NULL);
		double d_p2 = strtod(t_p2.c_str(),NULL);

		res = d_v + d_p1 * pow(2.0, 16.0) + d_p2 * pow(2.0, 16.0);
		returnvalue = res;
	}
	if(f_command == formulaCommand::ellipse)
	{
		//p2 * sqrt(1-(v/p1)^2)
		double d_v = strtod(t_v.c_str(),NULL);
		double d_p1 = strtod(t_p1.c_str(),NULL);
		double d_p2 = strtod(t_p2.c_str(),NULL);

		if(d_p1 != 0)
		{
			res = d_p2 * sqrt(1 - (d_v*d_v/d_p1*d_p1));
			returnvalue = res;
		}
		else
		{
			returnvalue = "0";
		}
	}
	if(f_command == formulaCommand::tan_)
	{
		double d_v = strtod(t_v.c_str(),NULL);
		double d_p1 = strtod(t_p1.c_str(),NULL);

		res = d_v * tan(d_p1);
	}

	return returnvalue;
}


int FormulaContainer::GetCommand(string eqn)
{
	if(eqn.compare("val") == 0 )
	{
		return formulaCommand::val;
	}
	if(eqn.compare("sum") == 0 )
	{
		return formulaCommand::sum;
	}
	if(eqn.compare("prod") == 0 )
	{
		return formulaCommand::product;
	}
	if(eqn.compare("mid") == 0 )
	{
		return formulaCommand::mid;
	}
	if(eqn.compare("abs") == 0 )
	{
		return formulaCommand::abs_;
	}
	if(eqn.compare("min") == 0 )
	{
		return formulaCommand::min;
	}
	if(eqn.compare("max") == 0 )
	{
		return formulaCommand::max;
	}
	if(eqn.compare("if") == 0 )
	{
		return formulaCommand::if_;
	}
	if(eqn.compare("mod") == 0 )
	{
		return formulaCommand::mod;
	}
	if(eqn.compare("atan2") == 0 )
	{
		return formulaCommand::atan2_;
	}
	if(eqn.compare("sin") == 0 )
	{
		return formulaCommand::sin_;
	}
	if(eqn.compare("cos") == 0 )
	{
		return formulaCommand::cos_;
	}
	if(eqn.compare("cosatan2") == 0 )
	{
		return formulaCommand::cosatan2;
	}
	if(eqn.compare("sinatan2") == 0 )
	{
		return formulaCommand::sinatan2;
	}
	if(eqn.compare("sqrt") == 0 )
	{
		return formulaCommand::sqrt_;
	}
	if(eqn.compare("sumangle") == 0 )
	{
		return formulaCommand::sumangle;
	}
	if(eqn.compare("ellipse") == 0 )
	{
		return formulaCommand::ellipse;
	}
	if(eqn.compare("tan") == 0 )
	{
		return formulaCommand::tan_;
	}

	return -1;
}

string FormulaContainer::GetResult()
{
	string result;
	int v;

	return result;
}

//Apply formula and calculate the formula values
void VML2SVG::ReadFormulaeNode(DOMElement *formulas, map<string,FormulaContainer> *formulaMap, vector<string> adjustList, DOMNamedNodeMap *styleAttrList)
{
	XMLCh *f_node = XMLString::transcode("v:f");
	XMLHelper *helper = XMLHelper::getInstance();
	DOMNodeList *formula_list = formulas->getElementsByTagName(f_node);
	DOMElement *node = NULL;
	string id;
	XMLSize_t list = formula_list->getLength();
	for(XMLSize_t i = 0; i < formula_list->getLength(); i++)
	{
		node = dynamic_cast<DOMElement*>(formula_list->item(i));
		XMLCh *formula_x = helper->GetAttributeValue(node, "eqn");

		id.erase();
		id.append("@").append(helper->convertToString((int)i));

		string formula = helper->convertToString(formula_x);

		FormulaContainer formulaNode(id, formula.c_str(), adjustList, styleAttrList);

		formulaMap->insert(std::pair<string, FormulaContainer>(id, formulaNode));	
	}
	XMLString::release((XMLCh**)&f_node);
}


//ColorHelper class 
ColorHelper::ColorHelper()
{	
	ColorHelper::populateMap();
}
XMLCh* ColorHelper::ParseFillColor(const XMLCh* fillcolor)
{	
	XMLHelper *helper = XMLHelper::getInstance();
	string fillcolor_s = XMLString::transcode(fillcolor);
	size_t pos = fillcolor_s.find(" ");
	string color = fillcolor_s.substr(0,pos);

	return helper->convertToXMLCh(color);
}
XMLCh* ColorHelper::GetColor(const XMLCh* hexCode)
{	
	if(hexCode == NULL)
	{
		NULL;
	}

	XMLHelper *helper = XMLHelper::getInstance();
	hexCode = ParseFillColor(hexCode);		
	string colorname = helper->convertToString(hexCode);	

	XMLCh *colorvalue = NULL;

	map<XMLCh*,XMLCh*>::iterator it = colorList.begin();

	while (it != colorList.end())	
	{
		if (XMLString::compareString(hexCode, it->first) == 0)
		{
			colorvalue = it->second;
			break;
		}
		it++;
	}

	if(colorvalue == NULL)
	{			
		//Not a standard color. Convert to RGB
		if((colorname.substr(0,1).compare("#") == 0) && ((int)colorname.length() > 4 ))
		{
			//split the hex value and return rgb(rr,gg,bb)
			string color;
			color.append("rgb(");

			string colorpart = colorname.substr(1,2);
			color.append(helper->convertToString(static_cast<int>(strtol(colorpart.c_str(), NULL, 16))));
			color.append(",");
			colorpart = colorname.substr(3,2);
			color.append(helper->convertToString(static_cast<int>(strtol(colorpart.c_str(), NULL, 16))));
			color.append(",");
			colorpart = colorname.substr(5,2);
			color.append(helper->convertToString(static_cast<int>(strtol(colorpart.c_str(), NULL, 16))));			
			color.append(")");

			colorvalue = helper->convertToXMLCh(color);
		}
		else
		{
			return const_cast<XMLCh*>(hexCode);
		}
	}		
	return colorvalue;	
}

void ColorHelper::populateMap()
{	
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("black"), XMLString::transcode("#000000")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#000080"), XMLString::transcode("navy")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#00008B"), XMLString::transcode("darkblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#0000CD"), XMLString::transcode("mediumblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#0000FF"), XMLString::transcode("blue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#006400"), XMLString::transcode("darkgreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#008000"), XMLString::transcode("green")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#008080"), XMLString::transcode("teal")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#008B8B"), XMLString::transcode("darkcyan")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#00BFFF"), XMLString::transcode("deepskyblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#00CED1"), XMLString::transcode("darkturquoise")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#00FA9A"), XMLString::transcode("mediumspringgreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#00FF00"), XMLString::transcode("lime")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#00FF7F"), XMLString::transcode("springgreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#00FFFF"), XMLString::transcode("cyan")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#00FFFF"), XMLString::transcode("aqua")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#191970"), XMLString::transcode("midnightblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#1E90FF"), XMLString::transcode("dodgerblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#20B2AA"), XMLString::transcode("lightseagreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#228B22"), XMLString::transcode("forestgreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#2E8B57"), XMLString::transcode("seagreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#2F4F4F"), XMLString::transcode("darkslategray")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#2F4F4F"), XMLString::transcode("darkslategrey")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#32CD32"), XMLString::transcode("limegreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#3CB371"), XMLString::transcode("mediumseagreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#40E0D0"), XMLString::transcode("turquoise")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#4169E1"), XMLString::transcode("royalblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#4682B4"), XMLString::transcode("steelblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#483D8B"), XMLString::transcode("darkslateblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#48D1CC"), XMLString::transcode("mediumturquoise")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#4B0082"), XMLString::transcode("indigo")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#556B2F"), XMLString::transcode("darkolivegreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#5F9EA0"), XMLString::transcode("cadetblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#6495ED"), XMLString::transcode("cornflowerblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#66CDAA"), XMLString::transcode("mediumaquamarine")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#696969"), XMLString::transcode("dimgrey")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#696969"), XMLString::transcode("dimgray")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#6A5ACD"), XMLString::transcode("slateblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#6B8E23"), XMLString::transcode("olivedrab")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#708090"), XMLString::transcode("slategrey")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#708090"), XMLString::transcode("slategray")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#778899"), XMLString::transcode("lightslategray(Hex3)")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#778899"), XMLString::transcode("lightslategrey(Hex3)")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#7B68EE"), XMLString::transcode("mediumslateblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#7CFC00"), XMLString::transcode("lawngreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#7FFF00"), XMLString::transcode("chartreuse")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#7FFFD4"), XMLString::transcode("aquamarine")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#800000"), XMLString::transcode("maroon")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#800080"), XMLString::transcode("purple")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#808000"), XMLString::transcode("olive")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#808080"), XMLString::transcode("gray")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#808080"), XMLString::transcode("grey")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#87CEEB"), XMLString::transcode("skyblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#87CEFA"), XMLString::transcode("lightskyblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#8A2BE2"), XMLString::transcode("blueviolet")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#8B0000"), XMLString::transcode("darkred")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#8B008B"), XMLString::transcode("darkmagenta")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#8B4513"), XMLString::transcode("saddlebrown")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#8FBC8F"), XMLString::transcode("darkseagreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#90EE90"), XMLString::transcode("lightgreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#9370DB"), XMLString::transcode("mediumpurple")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#9400D3"), XMLString::transcode("darkviolet")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#98FB98"), XMLString::transcode("palegreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#9932CC"), XMLString::transcode("darkorchid")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#9ACD32"), XMLString::transcode("yellowgreen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#A0522D"), XMLString::transcode("sienna")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#A52A2A"), XMLString::transcode("brown")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#A9A9A9"), XMLString::transcode("darkgray")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#A9A9A9"), XMLString::transcode("darkgrey")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#ADD8E6"), XMLString::transcode("lightblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#ADFF2F"), XMLString::transcode("greenyellow")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#AFEEEE"), XMLString::transcode("paleturquoise")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#B0C4DE"), XMLString::transcode("lightsteelblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#B0E0E6"), XMLString::transcode("powderblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#B22222"), XMLString::transcode("firebrick")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#B8860B"), XMLString::transcode("darkgoldenrod")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#BA55D3"), XMLString::transcode("mediumorchid")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#BC8F8F"), XMLString::transcode("rosybrown")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#BDB76B"), XMLString::transcode("darkkhaki")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#C0C0C0"), XMLString::transcode("silver")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#C71585"), XMLString::transcode("mediumvioletred")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#CD5C5C"), XMLString::transcode("indianred")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#CD853F"), XMLString::transcode("peru")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#D2691E"), XMLString::transcode("chocolate")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#D2B48C"), XMLString::transcode("tan")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#D3D3D3"), XMLString::transcode("lightgray")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#D3D3D3"), XMLString::transcode("lightgrey")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#D8BFD8"), XMLString::transcode("thistle")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#DA70D6"), XMLString::transcode("orchid")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#DAA520"), XMLString::transcode("goldenrod")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#DB7093"), XMLString::transcode("palevioletred")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#DC143C"), XMLString::transcode("crimson")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#DCDCDC"), XMLString::transcode("gainsboro")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#DDA0DD"), XMLString::transcode("plum")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#DEB887"), XMLString::transcode("burlywood")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#E0FFFF"), XMLString::transcode("lightcyan")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#E6E6FA"), XMLString::transcode("lavender")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#E9967A"), XMLString::transcode("darksalmon")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#EE82EE"), XMLString::transcode("violet")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#EEE8AA"), XMLString::transcode("palegoldenrod")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#F08080"), XMLString::transcode("lightcoral")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#F0E68C"), XMLString::transcode("khaki")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#F0F8FF"), XMLString::transcode("aliceblue")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#F0FFF0"), XMLString::transcode("honeydew")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#F0FFFF"), XMLString::transcode("azure")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#F4A460"), XMLString::transcode("sandybrown")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#F5DEB3"), XMLString::transcode("wheat")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#F5F5DC"), XMLString::transcode("beige")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#F5F5F5"), XMLString::transcode("whitesmoke")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#F5FFFA"), XMLString::transcode("mintcream")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#F8F8FF"), XMLString::transcode("ghostwhite")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FA8072"), XMLString::transcode("salmon")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FAEBD7"), XMLString::transcode("antiquewhite")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FAF0E6"), XMLString::transcode("linen")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FAFAD2"), XMLString::transcode("lightgoldenrodyellow")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FDF5E6"), XMLString::transcode("oldlace")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FF0000"), XMLString::transcode("red")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FF00FF"), XMLString::transcode("fuchsia")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FF00FF"), XMLString::transcode("magenta")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FF1493"), XMLString::transcode("deeppink")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FF4500"), XMLString::transcode("orangered")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FF6347"), XMLString::transcode("tomato")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FF69B4"), XMLString::transcode("hotpink")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FF7F50"), XMLString::transcode("coral")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FF8C00"), XMLString::transcode("darkorange")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFA07A"), XMLString::transcode("lightsalmon")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFA500"), XMLString::transcode("orange")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFB6C1"), XMLString::transcode("lightpink")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFC0CB"), XMLString::transcode("pink")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFD700"), XMLString::transcode("gold")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFDAB9"), XMLString::transcode("peachpuff")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFDEAD"), XMLString::transcode("navajowhite")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFE4B5"), XMLString::transcode("moccasin")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFE4C4"), XMLString::transcode("bisque")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFE4E1"), XMLString::transcode("mistyrose")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFEBCD"), XMLString::transcode("blanchedalmond")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFEFD5"), XMLString::transcode("papayawhip")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFF0F5"), XMLString::transcode("lavenderblush")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFF5EE"), XMLString::transcode("seashell")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFF8DC"), XMLString::transcode("cornsilk")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFFACD"), XMLString::transcode("lemonchiffon")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFFAF0"), XMLString::transcode("floralwhite")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFFAFA"), XMLString::transcode("snow")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFFF00"), XMLString::transcode("yellow")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFFFE0"), XMLString::transcode("lightyellow")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFFFF0"), XMLString::transcode("ivory")));
	colorList.insert(std::pair<XMLCh*,XMLCh*>(XMLString::transcode("#FFFFFF"), XMLString::transcode("white")));
}

//StyleHelper class
StyleHelper::StyleHelper()
{
}

/*
This method writes the attribute value and append to the node.
*/
void StyleHelper::WriteAttribute(DOMElement *node, char* attribute_key, char* attribute_value)
{
	/*XMLCh* key = XMLString::transcode(attribute_key);
	XMLCh* value = XMLString::transcode(attribute_value);
	node->setAttribute(key, value);*/
	XMLHelper *helper = XMLHelper::getInstance();
	XMLCh* key = XMLString::transcode(attribute_key);
	XMLCh* value = XMLString::transcode(attribute_value);
	const XMLCh* prev_val = node->getAttribute(key);
	if (helper->convertToString(key) == "transform" && prev_val != NULL)
	{
		string val = (helper->convertToString(prev_val)).append(helper->convertToString(value));
		node->setAttribute(key, helper->convertToXMLCh(val));
	}
	else
		node->setAttribute(key, value);

	XMLString::release(&key);
	XMLString::release(&value);
}
/*
This  method is used to write the attribute value and append to the node.
*/
void StyleHelper::WriteAttribute(DOMElement *node, char* attribute_key, XMLCh* attribute_value)
{ 
	if (attribute_value == NULL)
	{
		return ;
	}	
	/*XMLCh* key = XMLString::transcode(attribute_key);	
	node->setAttribute(key, attribute_value);
	XMLString::release(&key);*/	

	XMLHelper *helper = XMLHelper::getInstance();
	XMLCh* key = XMLString::transcode(attribute_key);
	const XMLCh* prev_val = node->getAttribute(key);
	if (helper->convertToString(key) == "transform" && prev_val != NULL)
	{
		string val = (helper->convertToString(prev_val)).append(helper->convertToString(attribute_value));
		node->setAttribute(key, helper->convertToXMLCh(val));
	}
	else
		node->setAttribute(key, attribute_value);

	XMLString::release(&key);
}

/*
This method is used to parse the style contents present in vml node(as attribute). 
The contents are broken into individuals attributes required for svg nodes, using this method.
*/
void StyleHelper::ParseStyle(XMLCh* style, map<string,XMLCh*> *styleMap)
{
	string style_s = XMLString::transcode(style);	
	vector<string> tokens;
	string key, value;
	XMLHelper *helper = XMLHelper::getInstance();

	helper->StrTokenize(style_s, ";", &tokens);
	vector<string>::iterator styleiter = tokens.begin();

	for(int i = 0; i < tokens.size(); i++)
	{
		string tokenpair = styleiter[i];

		int pos = tokenpair.find_first_of(":");

		if(pos != tokenpair.npos)
		{
			key = tokenpair.substr(0, pos);
			value = tokenpair.substr(pos + 1, tokenpair.length() - pos);
			styleMap->insert(std::pair<string, XMLCh*> (key, XMLString::transcode(value.c_str())));		
		}
	}
}

/*
This method is used to return the width to the svg after making corrections.
points to pixels conversion => pt*1.333 = px
VML		 SVG
width	width
*/
XMLCh* StyleHelper::GetWidthfromStyle(map<string,XMLCh*> *styleMap)
{	
	XMLHelper *helper = XMLHelper::getInstance();

	string width = "width";
	float width_px = 0.0;
	const XMLCh* xml_width = (*styleMap)[width];
	if(xml_width == NULL)
	{
		return NULL;
	}
	string attr_str = GetUnits(xml_width);
	if(attr_str == "in")
	{
		width_px = helper->convertToFloat(xml_width) * 72;
		attr_str = "pt";
	}
	else
	{	
		width_px = (helper->convertToFloat(xml_width));
	}	

	return helper->convertToXMLCh((helper->convertToString(width_px)).append(attr_str) );
}

/*
This method is used to return the height to the svg after making corrections.
points to pixels conversion => pt*1.333 = px
VML		 SVG
height	height
*/
XMLCh* StyleHelper::GetHeightfromStyle(map<string,XMLCh*> *styleMap)
{	
	XMLHelper *helper = XMLHelper::getInstance();		
	string height = "height";
	float height_px = 0.0;

	const XMLCh* Xml_height = (*styleMap)[height];
	const XMLCh* min_height = XMLString::transcode("0");
	if((Xml_height == NULL) || (XMLString::compareString(Xml_height, min_height) == 0))
	{
		return NULL;
	}
	string attr_str = GetUnits(Xml_height);

	if(attr_str == "in")
	{
		height_px = helper->convertToFloat(Xml_height) * 72;
		attr_str = "pt";
	}
	else
	{	
		height_px = (helper->convertToFloat(Xml_height));
	}	

	return helper->convertToXMLCh((helper->convertToString(height_px)).append(attr_str));
}

/*
This method is used to return the value of the x-coordinate to the svg after making corrections.
points to pixels conversion => pt*1.333 = px
VML				SVG
margin-left		x
*/
XMLCh* StyleHelper::GetXcoordinatefromStyle(map<string,XMLCh*> *styleMap)
{	
	XMLHelper *helper = XMLHelper::getInstance();		
	string str_x = "margin-left";

	XMLCh* Xml_x = const_cast<XMLCh*>((*styleMap)[str_x]);
	XMLCh* Xml_x0 = XMLString::transcode("0");
	//if((Xml_x == NULL) || XMLString::compareString(Xml_x, Xml_x0))
	if(Xml_x == NULL)
	{
		str_x.erase();

		str_x = "left";

		Xml_x = const_cast<XMLCh*>((*styleMap)[str_x]);
		if(Xml_x == NULL)
		{
			return NULL;
		}

	}	
	string attr_str = GetUnits(Xml_x);
	float x_px = (helper->convertToFloat(Xml_x));

	return helper->convertToXMLCh((helper->convertToString(x_px)).append(attr_str) );
}

/*
This method is used to return the value of the y-coordinate to the svg after making corrections.
points to pixels conversion => pt*1.333 = px
VML				SVG
margin-top		y
*/
XMLCh* StyleHelper::GetYcoordinatefromStyle(map<string,XMLCh*> *styleMap)
{	
	XMLHelper *helper = XMLHelper::getInstance();
	string str_y = "margin-top";
	XMLCh* Xml_y = const_cast<XMLCh*>((*styleMap)[str_y]);

	if(Xml_y == NULL)
	{
		str_y.erase();

		str_y = "top";
		Xml_y = const_cast<XMLCh*>((*styleMap)[str_y]);

		if(Xml_y == NULL)
		{
			return NULL;
		}
	}
	string attr_str = GetUnits(Xml_y);
	float y_px = (helper->convertToFloat(Xml_y));


	return helper->convertToXMLCh((helper->convertToString(y_px)).append(attr_str) );
}
/*
This method is used to return the value of the cx-coordinate to the svg after making corrections.
points to pixels conversion => pt*1.333 = px
VML				SVG
margin-left		cx

This is used in case of ellipse (svg)/ v:oval, v:circle (vml) nodes.
cx = margin-left + rx
*/
XMLCh* StyleHelper::GetCXfromStyle(map<string,XMLCh*> *styleMap, float rx)
{	
	XMLHelper *helper = XMLHelper::getInstance();
	string str_cx = "margin-left";		
	XMLCh* Xml_cx = const_cast<XMLCh*>((*styleMap)[str_cx]);

	if(Xml_cx == NULL)
	{
		str_cx.erase();

		str_cx = "left";
		Xml_cx = const_cast<XMLCh*>((*styleMap)[str_cx]);

		if(Xml_cx == NULL)
		{
			return XMLString::transcode(" ");
		}
	}
	string attr_str = GetUnits(Xml_cx);
	float cx_px = ((helper->convertToFloat(Xml_cx)) + rx);// * 1.33;

	return helper->convertToXMLCh((helper->convertToString(cx_px)).append(attr_str));//.append(attr_str) );
}

/*
This method is used to return the value of the cy-coordinate to the svg after making corrections.
points to pixels conversion => pt*1.333 = px
VML				SVG
margin-top		cy

This is used in case of ellipse (svg)/ v:oval, v:circle (vml) nodes.
cx = margin-left + ry
*/
XMLCh* StyleHelper::GetCYfromStyle(map<string,XMLCh*> *styleMap, float ry)
{	
	XMLHelper *helper = XMLHelper::getInstance();
	string str_cy = "margin-top";	

	XMLCh* Xml_cy = const_cast<XMLCh*>((*styleMap)[str_cy]);

	if(Xml_cy == NULL)
	{
		str_cy.erase();

		str_cy = "top";
		Xml_cy = const_cast<XMLCh*>((*styleMap)[str_cy]);

		if(Xml_cy == NULL)
		{
			return XMLString::transcode(" ");
		}
	}
	string attr_str = GetUnits(Xml_cy);
	float cy_px = ((helper->convertToFloat(Xml_cy)) + ry); //* 1.33;

	return helper->convertToXMLCh((helper->convertToString(cy_px)).append(attr_str));//.append(attr_str) );
}


/*
This method is used to return the value of the rx-coordinate to the svg after making corrections.
points to pixels conversion => pt*1.333 = px
VML			SVG
width		rx/2

This is used in case of ellipse (svg)/ v:oval, v:circle (vml) nodes.
*/
XMLCh* StyleHelper::GetRXfromStyle(map<string,XMLCh*> *styleMap)
{	
	XMLHelper *helper = XMLHelper::getInstance();
	string rx = "width";	

	const XMLCh* Xml_rx = (*styleMap)[rx];

	if(Xml_rx == NULL)
	{
		return NULL;
	}

	float rx_px = 0.0;
	string attr_str = GetUnits(Xml_rx);

	if(attr_str == "in")
	{
		rx_px = (helper->convertToFloat(Xml_rx)/2) * 72;
		attr_str = "pt";
	}
	else
	{	
		rx_px = (helper->convertToFloat(Xml_rx)/2);
	}	

	return helper->convertToXMLCh((helper->convertToString(rx_px)).append(attr_str));
}

/*
This method is used to return the value of the ry-coordinate to the svg after making corrections.
points to pixels conversion => pt*1.333 = px
VML			SVG
height		ry/2

This is used in case of ellipse (svg)/ v:oval, v:circle (vml) nodes.
*/
XMLCh* StyleHelper::GetRYfromStyle(map<string,XMLCh*> *styleMap)
{	
	XMLHelper *helper = XMLHelper::getInstance();
	string ry = "height";	

	const XMLCh* Xml_ry = (*styleMap)[ry];

	if(Xml_ry == NULL)
	{
		return NULL;
	}
	/*string attr_str = GetUnits(Xml_ry);
	float ry_px = (helper->convertToFloat(Xml_ry)/2);

	return helper->convertToXMLCh((helper->convertToString(ry_px)).append(attr_str) );*/

	float ry_px = 0.0;
	string attr_str = GetUnits(Xml_ry);

	if(attr_str == "in")
	{
		ry_px = (helper->convertToFloat(Xml_ry)/2) * 72;
		attr_str = "pt";
	}
	else
	{	
		ry_px = (helper->convertToFloat(Xml_ry)/2);
	}	

	return helper->convertToXMLCh((helper->convertToString(ry_px)).append(attr_str));
}

/*
This method return the Z attributes value
*/
XMLCh* StyleHelper::GetZAttrfromStyle(map<string,XMLCh*> *styleMap)
{
	XMLHelper *helper = XMLHelper::getInstance();
	string zindex = "z-index";	

	const XMLCh* Xml_zindex = (*styleMap)[zindex];

	if(Xml_zindex == NULL)
	{
		return NULL;
	}
	return (XMLCh*)Xml_zindex;
}

/*
This method return the Z attributes value
*/
XMLCh* StyleHelper::GetZAttrfromStyle(DOMNode *wpict)
{

	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper;
	DOMNodeList* vmlchildlist = wpict->getChildNodes();

	XMLSize_t  child_list = vmlchildlist->getLength();
	if(child_list != NULL && child_list > 1)
	{
		for(XMLSize_t i = 0;i < child_list;i++){
			if(XMLString::compareString(vmlchildlist->item(i)->getNodeName(), XMLString::transcode("v:shape")) == 0)
			{		
				DOMNamedNodeMap *vml_attr_map = vmlchildlist->item(i)->getAttributes();
				map<string, XMLCh*> styleMap;
				styleHelper.ParseStyle(helper->GetAttributeValue(vml_attr_map, "style"), &styleMap);
				return styleHelper.GetZAttrfromStyle(&styleMap);
			}
		}
	}
	else
	{
		DOMNode* vml = wpict->getFirstChild();
		DOMNamedNodeMap *vml_attr_map = vml->getAttributes();
		map<string, XMLCh*> styleMap;
		styleHelper.ParseStyle(helper->GetAttributeValue(vml_attr_map, "style"), &styleMap);
		return styleHelper.GetZAttrfromStyle(&styleMap);
	}

}

/*
This method is used to return the rotation angles to the svg.

VML		            SVG
rotation	        transform="rotate(x)"
*/

XMLCh* StyleHelper::GetRotateTransformFromStyle(DOMElement *svg_node, float rotate_convert, float coord_x, float coord_y)
{	
	XMLHelper *helper = XMLHelper::getInstance();
	std::stringstream ss, ssx, ssy;
	std::string rt_conv;
	string transform = "";

	std::string co_x, co_y;

	if (helper->convertToXMLCh(rotate_convert))
	{
		ss << rotate_convert;
		ss >> rt_conv;

		if (helper->convertToXMLCh(coord_x)){
			ssx << coord_x;
			ssx>> co_x;
		}

		if (helper->convertToXMLCh(coord_y)){
			ssy << coord_y;
			ssy >> co_y;
		}

		if (XMLString::compareString(svg_node->getNodeName(), XMLString::transcode("path")) == 0)
		{

			transform.append("rotate(");
			transform.append(rt_conv);
			transform.append(" 10800 10800)");
		}
		else if (XMLString::compareString(svg_node->getNodeName(), XMLString::transcode("rect")) == 0)
		{

			transform.append("translate(").append(co_x).append(" ");
			transform.append(co_x).append(")").append(" rotate(");
			transform.append(rt_conv).append(")").append(" translate(-");
			transform.append(co_x).append(" -").append(co_y).append(")");		
		}
		else
		{
			transform.append("rotate(");
			transform.append(rt_conv);
			transform.append(")");
		}
		return helper->convertToXMLCh(transform);
	}
	return helper->convertToXMLCh("");

}

/*
This method return the rotation attribute's value
*/
XMLCh* StyleHelper::GetRotationAttrFromStyle(map<string,XMLCh*> *styleMap)
{
	XMLHelper *helper = XMLHelper::getInstance();
	string rotation = "rotation";
	float rotn = 0.0;

	const XMLCh* Xml_rotation = (*styleMap)[rotation];

	if(Xml_rotation == NULL)
	{
		return helper->convertToXMLCh(rotn);
	}

	rotn = (helper->convertToFloat(Xml_rotation)/65536);

	if (rotn < 0.05 && rotn > -0.05){
		int rotn_90;
		rotn_90 = helper->convertToInt(Xml_rotation);

		if((rotn_90 % 90) == 0){
			if(rotn_90 < 0)
				rotn_90 = -90;
			if (rotn_90 > 0)
				rotn_90 = 90;
		}
		rotn = helper->convertToFloat(helper->convertToXMLCh(rotn_90));
	}
	return helper->convertToXMLCh(rotn);
}


/*
This method is used to return the flip co-ordinates to the svg.

VML		                        SVG
flip("x/y/xy/yx")	            scale"(-1,1)/(1,-1)/(-1-1)/(-1,-1)"
*/

XMLCh* StyleHelper::GetFlipAttrValueForSVG(string flip_attribute)
{	
	XMLHelper *helper = XMLHelper::getInstance();

	if (flip_attribute == "")
	{
		return helper->convertToXMLCh("");
	}
	string scale_coord = " scale";
	scale_coord.append(flip_attribute);

	return helper->convertToXMLCh(scale_coord);
}

/*
This method return the flip attribute's value
*/
XMLCh* StyleHelper::GetFlipAttrFromStyle(map<string,XMLCh*> *styleMap, DOMElement *svg_node)
{
	XMLHelper *helper = XMLHelper::getInstance();
	string flip = "flip";
	string flip_in_svg = "";

	StyleHelper styleHelper;	


	float flip_x;
	float flip_y; 
	float corr_flip_x = 0; 
	float corr_flip_y = 0;	

	map<string, XMLCh*>::iterator it = styleMap->begin();
	const XMLCh* Xml_flip = (*styleMap)[flip];

	if(Xml_flip == NULL)
	{
		return helper->convertToXMLCh(flip_in_svg);
	}

	if((helper->convertToString(Xml_flip)) == "x")
	{
		flip_in_svg = "(-1, 1)"; 

		if(helper->convertToString(svg_node->getNodeName()) == "path")
			flip_in_svg = "(-1, 1) translate(0 21600) translate(-21600 -21600)";

		if(helper->convertToString(svg_node->getNodeName()) == "rect")
		{
			flip_x = helper->convertToFloat(styleHelper.GetXcoordinatefromStyle(styleMap)); 
			flip_y = helper->convertToFloat(styleHelper.GetYcoordinatefromStyle(styleMap));

			const XMLCh *ry = svg_node->getAttribute(XMLString::transcode("ry"));
			if(helper->convertToString(ry) == " ")	
			{
				corr_flip_x = 1.58 * flip_x;

				flip_in_svg = "(-1, 1) translate(";
				flip_in_svg.append(helper->convertToString(-corr_flip_x));
				flip_in_svg.append(", ");
				flip_in_svg.append(helper->convertToString(flip_y)); 
				flip_in_svg.append("), translate(");
				flip_in_svg.append(helper->convertToString(-flip_x));
				flip_in_svg.append(", ");
				flip_in_svg.append(helper->convertToString(-flip_y)); 
				flip_in_svg.append(")");
			}
			else
			{
				corr_flip_x = 0.49 * flip_x;

				flip_in_svg = "(-1, 1) translate(";
				flip_in_svg.append(helper->convertToString(-corr_flip_x));
				flip_in_svg.append(", ");
				flip_in_svg.append(helper->convertToString(flip_y)); 
				flip_in_svg.append("), translate(");
				flip_in_svg.append(helper->convertToString(-flip_x));
				flip_in_svg.append(", ");
				flip_in_svg.append(helper->convertToString(-flip_y)); 
				flip_in_svg.append(")");
			}
		}
	}

	if((helper->convertToString(Xml_flip)) == "y")
	{
		flip_in_svg = "(1, -1)";

		if(helper->convertToString(svg_node->getNodeName()) == "path")
			flip_in_svg = "(1, -1) translate(21600 0) translate(-21600 -21600)";

		if(helper->convertToString(svg_node->getNodeName()) == "rect")
		{
			flip_x = helper->convertToFloat(styleHelper.GetXcoordinatefromStyle(styleMap)); 
			flip_y = helper->convertToFloat(styleHelper.GetYcoordinatefromStyle(styleMap));

			const XMLCh *ry = svg_node->getAttribute(XMLString::transcode("ry"));
			if(helper->convertToString(ry) == " ")	
			{	
				corr_flip_y = flip_x / 2;;
				flip_in_svg = "(1, -1) translate(";
				flip_in_svg.append(helper->convertToString(flip_x));
				flip_in_svg.append(", ");
				flip_in_svg.append(helper->convertToString(corr_flip_y)); 
				flip_in_svg.append("), translate(");
				flip_in_svg.append(helper->convertToString(-flip_x));
				flip_in_svg.append(", ");
				flip_in_svg.append(helper->convertToString(-flip_y)); 
				flip_in_svg.append(")");
			}
			else
			{
				corr_flip_y = - (1.95 * flip_x);
				flip_in_svg = "(1, -1) translate(";
				flip_in_svg.append(helper->convertToString(flip_x));
				flip_in_svg.append(", ");
				flip_in_svg.append(helper->convertToString(corr_flip_y)); 
				flip_in_svg.append("), translate(");
				flip_in_svg.append(helper->convertToString(-flip_x));
				flip_in_svg.append(", ");
				flip_in_svg.append(helper->convertToString(corr_flip_y)); 
				flip_in_svg.append(")");
			}
		}
	}
	if(((helper->convertToString(Xml_flip)) == "x y") || ((helper->convertToString(Xml_flip)) == "y x"))
	{	
		flip_in_svg = "(-1, -1)";

		if(helper->convertToString(svg_node->getNodeName()) == "path")
			flip_in_svg = "(-1, -1) translate(0 0) translate(-21600 -21600)";

		if(helper->convertToString(svg_node->getNodeName()) == "rect")
		{
			flip_x = helper->convertToFloat(styleHelper.GetXcoordinatefromStyle(styleMap)); 
			flip_y = helper->convertToFloat(styleHelper.GetYcoordinatefromStyle(styleMap));

			const XMLCh *ry = svg_node->getAttribute(XMLString::transcode("ry"));
			if(helper->convertToString(ry) == " ")	
			{
				flip_in_svg = "(-1, -1) translate() translate(";
				flip_in_svg.append(helper->convertToString(-flip_x));
				flip_in_svg.append(", ");
				flip_in_svg.append(helper->convertToString(-flip_y)); 
				flip_in_svg.append(")");
			}
			else
			{
				flip_in_svg = "(-1, -1) translate() translate(";
				flip_in_svg.append(helper->convertToString(-flip_x)).append(", ");
				flip_in_svg.append(helper->convertToString(-flip_y)).append(")"); 
			}
		}
	}
	return helper->convertToXMLCh(flip_in_svg);
}


string StyleHelper::GetUnits(const XMLCh* attr)
{
	XMLHelper *helper = XMLHelper::getInstance();
	string attr_str =helper->convertToString(attr);
	string unit = "";
	size_t pos = attr_str.length();
	if((!attr_str.empty()) && (pos > 1))
	{
		pos = pos - 2;
		unit = attr_str.substr(pos, 2);
		if(unit == "in")
		{
			return unit;
		}
		if(unit == "pt") 
		{
			return "pt";
		}
		unit="";
	}
	return unit;
}


/*
This method sets the parent node for the textbox node 
*/
void VML2SVG::SetTextboxParentNode(DOMElement *svg, DOMElement *parent_svg, DOMElement *text_parent_node, DOMElement *current_parent_node, DOMNamedNodeMap *vml_attr_map)
{
	XMLHelper *helper = XMLHelper::getInstance();
	StyleHelper styleHelper; 
	ColorHelper colorHelper;
	int i_x;
	int i_y;
	XMLCh *flag = XMLString::transcode("f");
	string parent = helper->convertToString(current_parent_node->getNodeName());		

	if (parent == "path")
	{
		DOMElement *parent_txbx = dynamic_cast <DOMElement*> (parent_svg->cloneNode(true));
		
		float f_x = (helper->convertToFloat(helper->GetAttributeValue(parent_txbx, "width"))) / 1.5;
		float f_y = (helper->convertToFloat(helper->GetAttributeValue(parent_txbx, "height")) / 2) + 15;

		svg->appendChild(parent_svg);

		parent_svg->appendChild(current_parent_node);

		svg->appendChild(parent_txbx);
		parent_txbx->removeAttribute(XMLString::transcode("viewBox"));
		const XMLCh *attr = parent_txbx->getAttribute(XMLString::transcode("viewBox"));

		parent_txbx->appendChild(text_parent_node);

		i_x =  helper->convertToFloat(parent_txbx->getAttribute(XMLString::transcode("x")));
		i_y =  helper->convertToFloat(parent_txbx->getAttribute(XMLString::transcode("y"))) + 10;

		if((f_x < i_x) && (f_y < i_y))
		{
			text_parent_node->setAttribute(XMLString::transcode("x"), helper->convertToXMLCh(f_x));
			text_parent_node->setAttribute(XMLString::transcode("y"), helper->convertToXMLCh(f_y));
		}
		else
		{
			text_parent_node->setAttribute(XMLString::transcode("x"), helper->convertToXMLCh(i_x));
			text_parent_node->setAttribute(XMLString::transcode("y"), helper->convertToXMLCh(i_y));
		}

		if(helper->convertToString(svg->getNodeName()) == "g")
		{
			styleHelper.WriteAttribute(text_parent_node, "font-size", "200");
		}		 	

		if((helper->GetAttributeValue(vml_attr_map, "fillcolor") != NULL) && XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "filled"), flag) != 0)
		{
			styleHelper.WriteAttribute(parent_svg, "fill", colorHelper.GetColor(helper->GetAttributeValue(vml_attr_map, "fillcolor")));
		}
		else
		{
			if(XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "filled"), flag) == 0)
			{
				styleHelper.WriteAttribute(parent_svg, "fill-opacity", "0.0");
				
				if (XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "stroked"), flag) == 0)
				{
					styleHelper.WriteAttribute(parent_svg, "stroke-opacity", "0");
				}				
			}
			/*else
			{
				styleHelper.WriteAttribute(parent_svg, "fill-opacity", "0");
			}	*/		
		}


		return;
	}	
	else if (parent == "ellipse")
	{
		const XMLCh *attr = current_parent_node->getAttribute(XMLString::transcode("transform"));

		if(helper->convertToString(attr) != "")
		{
			i_x = 0;
			i_y = 0;
		}
		else
		{
			i_x = helper->convertToFloat(current_parent_node->getAttribute(XMLString::transcode("x")));
			i_y = helper->convertToFloat(current_parent_node->getAttribute(XMLString::transcode("y")));
		}

		text_parent_node->setAttribute(XMLString::transcode("x"), helper->convertToXMLCh(i_x));
		text_parent_node->setAttribute(XMLString::transcode("y"), helper->convertToXMLCh(i_y));
	}	 

	else
	{
		i_x = helper->convertToFloat(current_parent_node->getAttribute(XMLString::transcode("x"))) * 1.33;
		i_y = helper->convertToFloat(current_parent_node->getAttribute(XMLString::transcode("y"))) * 1.05;

		text_parent_node->setAttribute(XMLString::transcode("x"), helper->convertToXMLCh(i_x));
		text_parent_node->setAttribute(XMLString::transcode("y"), helper->convertToXMLCh(i_y));
	}

	if(helper->convertToString(svg->getNodeName()) == "g")
	{
		styleHelper.WriteAttribute(text_parent_node, "font-size", "200");
	}
	
	
		if((helper->GetAttributeValue(vml_attr_map, "fillcolor") != NULL) && XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "filled"), flag) != 0)
		{
			styleHelper.WriteAttribute(current_parent_node, "fill", colorHelper.GetColor(helper->GetAttributeValue(vml_attr_map, "fillcolor")));
		}
		else
		{
			if(XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "filled"), flag) == 0)
			{
				styleHelper.WriteAttribute(current_parent_node, "fill-opacity", "0.0");
				
				if (XMLString::compareString(helper->GetAttributeValue(vml_attr_map, "stroked"), flag) == 0)
				{
					styleHelper.WriteAttribute(current_parent_node, "stroke-opacity", "0");
				}				
			}
			/*else
			{
				styleHelper.WriteAttribute(current_parent_node, "fill-opacity", "0");
			}	*/		
		}

	svg->appendChild(parent_svg);
	parent_svg->appendChild(current_parent_node);
	parent_svg->appendChild(text_parent_node);

	return;
}